var request = require('request');
console.log("Pock iniciada!!!");

var ceps = {
    1: "09750-440",
    2: "09685-030",
    3: "09691-350",
    4: "09720-970",
    5: "09765-310",
    6: "09860-125",
    7: "09896-260",
    8: "09853-550",
    9: "09894-480",
    10: "09832-460",
    11: "09785-060",
    12: "09691-080",
    13: "09851-466",
    14: "09780-520",
    15: "09852-445"
};

var categorias = {
    1: [1, 2, 3],
    2: [4, 5, 6],
    3: [7, 8, 9, 10],
    4: [11, 12, 13],
    5: [14, 15, 16],
    6: [1, 9, 37],
    7: [17, 2, 18, 19, 20],
    8: [21, 38, 23, 34],
    9: [22, 24, 25, 26, 27]
};

var profissoes = {
    1: [1, 2],
    2: [2, 3],
    3: [3, 4],
    4: [1, 3],
    5: [2, 4],
    6: [2]
};

for (var i = 4706; i <= 5350; i++) {
    var fotografo = {
        nome: "Roberto Teste 2",
        nome_exibicao: "Roberto",
        descricao: "Meu nome é Roberto e tiro fotos",
        is_empresa: false,
        site: "www.roberto.com.br",
        email: "reoberto@hotmail.com",
        telefone: "1234 - 1234",
        celular: "12345 - 1234",
        is_whatsapp: true,
        ano_inico_trabalho: 2016,
        senha: 123456,
        pais_id: 1,
        estado_id: 26,
        cep: "",
        cidade_id: 0,
        bairro: "Meu bairro",
        rua: "Minha rua",
        numero: 123,
        complemento: "Meu complemento",
        categorias: [],
        profissoes: [],
        sexo_id: 1
    };

    fotografo.cidade_id = i;
    fotografo.cep = ceps[getRandom(15)];
    fotografo.categorias = categorias[getRandom(9)];
    fotografo.profissoes = profissoes[getRandom(6)];

    criaUsuario(fotografo, printaRetorno);
}

function printaRetorno(error, body) {
    if (error) {
        console.log(error);
    }

    console.log("Fotografo criado!!!! [ID] -> " + JSON.parse(body).fotografo.id);
}

function criaUsuario(_fotografo, callback) {
    request.post({
        headers: { 'content-type': "application/json" },
        url: "http://localhost:7001/api/fotografo",
        body: JSON.stringify({ "fotografo": _fotografo })
    }, function (error, response, body) {
        if (error) {
            callback(error);
            return;
        }

        callback(null, body);
    });
}





function getRandom(max) {
    return Math.floor(Math.random() * max + 1);
}