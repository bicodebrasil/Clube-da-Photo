/* global __dirDomain */
var express = require('express');
var marketingCategoriaService = require(__dirDomain + 'services/marketingCategoriaService');
var anuncioService = require(__dirDomain + 'services/anuncioService');
var router = express.Router();

/**
 * @api {get} /api/marketing/categorias ListaCategorias
 * @apiDescription Devolve a listagem de categorias
 * @apiName ListaCategorias
 * @apiGroup Marketing 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "categorias": [
 *          {
 *              "id": 1,
 *              "descricao": "Seguradora",
 *              "icone": null
 *          },
 *          {
 *              "id": 2,
 *              "descricao": "Equipamentos",
 *              "icone": null
 *          },
 *          {
 *              "id": 3,
 *              "descricao": "Aluguel de Estúdio",
 *              "icone": null
 *          }
 *      ]
 * }
 */
router.get('/categorias', function (req, res) {
    marketingCategoriaService.listagemDeCategorias(function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {post} /api/marketing/categorias AdicionaCategoria
 * @apiDescription Adiciona uma nova categoria
 * @apiName AdicionaCategoria
 * @apiGroup Marketing 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "categoria": {} 
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "categoria": {...}
 * }
 */
router.post('/categorias', function (req, res) {
    if (req.body.categoria) {
        marketingCategoriaService.adicionaCategoria(req.body.categoria, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json("Categoria não informada!");
    }
});

/**
 * @api {get} /api/marketing/anuncios/todos ListaTodosAnuncios
 * @apiDescription Devolve a listagem de todos os anuncios
 * @apiName ListaTodosAnuncios
 * @apiGroup Marketing 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "anuncios": [
 *          {
 *              "id": 2,
 *              "categoria_id": 15,
 *              "url": "http://link.com.net.br",
 *              "foto_anuncio_path": "homologacao/anuncios/20161016171633_Wedding-Kiss-Photos-2013-HD-Wallpaper.jpg",
 *              "foto_anuncio_url": "https://www.dropbox.com/s/nsebssg45aakfff/20161016171633_Wedding-Kiss-Photos-2013-HD-Wallpaper.jpg?raw=1",
 *              "data_criacao": "2016-10-16T19:16:41.000Z",
 *              "data_alteracao": "2016-10-16T19:16:41.000Z"
 *          }
 *      ]
 * }
 */
router.get('/anuncios/todos', function (req, res) {
    anuncioService.listagemDeTodos(function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {get} /api/marketing/anuncios/:categoria_id ListaAnunciosPorCategoria
 * @apiDescription Devolve a listagem de anuncios por categoria
 * @apiName ListaAnunciosPorCategoria
 * @apiGroup Marketing 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "anuncios": [
 *          {
 *              "id": 2,
 *              "categoria_id": 15,
 *              "url": "http://link.com.net.br",
 *              "foto_anuncio_path": "homologacao/anuncios/20161016171633_Wedding-Kiss-Photos-2013-HD-Wallpaper.jpg",
 *              "foto_anuncio_url": "https://www.dropbox.com/s/nsebssg45aakfff/20161016171633_Wedding-Kiss-Photos-2013-HD-Wallpaper.jpg?raw=1",
 *              "data_criacao": "2016-10-16T19:16:41.000Z",
 *              "data_alteracao": "2016-10-16T19:16:41.000Z"
 *          }
 *      ]
 * }
 */
router.get('/anuncios/:categoria_id', function (req, res) {
    anuncioService.listagemPorCategoria(req.params.categoria_id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {post} /api/marketing/anuncios AdicionaAnuncio
 * @apiDescription Adiciona um anuncio
 * @apiName AdicionaAnuncio
 * @apiGroup Marketing 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "--ARQUIVO--": {},
 *      "file": {},
 *      "url: "",
 *      "categoria_id": 1
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "anuncio": {...}
 * }
 */
router.post('/anuncios', function (req, res) {
    var file = null;

    if (req.files) {
        file = req.files.file;
    }

    anuncioService.adicionaAnuncio(req.body, file, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;