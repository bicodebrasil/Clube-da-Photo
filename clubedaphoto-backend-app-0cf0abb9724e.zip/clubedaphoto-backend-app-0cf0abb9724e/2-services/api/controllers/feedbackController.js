/* global __dirDomain */
var express = require('express');
var feedbackService = require(__dirDomain + 'services/feedbackService');
var router = express.Router();

/**
 * @api {post} /api/feedback AdicionaFeedback
 * @apiDescription Adiciona um feedback
 * @apiName AdicionaFeedback
 * @apiGroup Feedback 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "feedback":{
 *           "texto": "APP muito bom, parabéns!",
 *           "fotografo_id": 8
 *      }
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "feedback": {
 *          "data_criacao": "2016-10-19T00:01:32.239Z",
 *          "data_alteracao": "2016-10-19T00:01:32.239Z",
 *          "id": 1,
 *          "texto": "APP muito bom, parabéns!",
 *          "fotografo_id": 8,
 *          "status_id": 1
        }
 * }
 */
router.post('/', function (req, res) {
    if (req.body.feedback) {
        feedbackService.criaFeedback(req.body.feedback, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json("Feedback não informado!");
        return;
    }
});

module.exports = router;