/* global __dirDomain */
var express = require('express');
var paisService = require(__dirDomain + 'services/paisService');
var router = express.Router();

/**
 * @api {get} /api/paises ListaPaises
 * @apiDescription Devolve a listagem de países
 * @apiName ListaPaises
 * @apiGroup Países 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "paises": [
 *          {
 *              "id": 1,
 *              "descricao": "Brasil",
 *              "sigla": "BR"
 *          }
 *      ]
 * }
 */
router.get('/', function (req, res) {
    paisService.listagemDePaises(function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;