/* global __dirDomain */
var express = require('express');
var profissaoService = require(__dirDomain + 'services/profissaoService');
var router = express.Router();
var filtroToken = require('../middlewares/validaToken');

/**
 * @api {get} /api/profissoes ListaProfissoes
 * @apiDescription Devolve a listagem de profissoes
 * @apiName ListaProfissoes
 * @apiGroup Profissoes 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "profissoes": [
 *          {
 *              "id": 1,
 *              "descricao": "Fotografo",
 *              "icone": null
 *          },
 *          {
 *              "id": 2,
 *              "descricao": "Cinegrafista",
 *              "icone": null
 *          },
 *          {
 *              "id": 3,
 *              "descricao": "Diagramador",
 *              "icone": null
 *          }
 *      ]
 * }
 */
router.get('/', function (req, res) {
    profissaoService.listagemDeProfissoes(function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

router.use(filtroToken.validaToken);

/**
 * @api {post} /api/profissoes GravaProfissaoPorFotografo
 * @apiDescription Grava uma noova profissao para o fotografo
 * @apiName GravaProfissaoPorFotografo
 * @apiGroup Profissoes 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "profissao": {
 *          "fotografo_id: 1,
 *          "profissao_id": 1
 *      }
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.post('/', function (req, res) {
    if (req.body.profissao) {
        profissaoService.gravaProfissaoPorFotografo(req.body.profissao, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Profissão não informada!" });
        return;
    }
});

/**
 * @api {delete} /api/profissoes/:id ExcluiProfissaoPorFotografo
 * @apiDescription Exclui uma profissao por fotografo
 * @apiName ExcluiProfissaoPorFotografo
 * @apiGroup Profissoes 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.delete('/:id', function (req, res) {
    profissaoService.exlcuiProfissaoPorFotografo(req.fotografo.id, req.params.id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;