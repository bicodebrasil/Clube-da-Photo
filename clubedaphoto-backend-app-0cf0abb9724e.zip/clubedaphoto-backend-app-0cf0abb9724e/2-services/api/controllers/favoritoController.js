/* global __dirDomain */
var express = require('express');
var router = express.Router();
var favoritoService = require(__dirDomain + 'services/favoritoService');
var filtroToken = require('../middlewares/validaToken');

router.use(filtroToken.validaToken);

/**
 * @api {post} /api/favorito AddFavorito
 * @apiDescription Adiciona um favorito
 * @apiName AddFavorito
 * @apiGroup Favoritos 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "favorito_id": 1  
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.post('/', function (req, res) {
    if (req.body.favorito_id) {
        favoritoService.adicionaFavorito(req.fotografo.id, req.body.favorito_id, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Favorito não informado!" });
        return;
    }
});

/**
 * @api {delete} /api/favorito/:favorito_id RemoveFavorito
 * @apiDescription Remove um favorito
 * @apiName RemoveFavorito
 * @apiGroup Favoritos 
 * 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.delete('/:favorito_id', function (req, res) {
    favoritoService.removeFavorito(req.fotografo.id, req.params.favorito_id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;