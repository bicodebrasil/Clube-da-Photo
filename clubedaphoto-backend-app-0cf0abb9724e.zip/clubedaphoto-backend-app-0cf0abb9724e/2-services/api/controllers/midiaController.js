/* global __dirDomain */
var express = require('express');
var router = express.Router();
var midiaService = require(__dirDomain + 'services/midiaService');
var filtroToken = require('../middlewares/validaToken');

router.use(filtroToken.validaToken);

/**
 * @api {post} /api/midias/video GravaVideo
 * @apiDescription Grava um video na midia do fotografo
 * @apiName GravaVideo
 * @apiGroup Midia 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *	    "midia": {
 *          "descricao": "Vídeo bacana",
 *          "video_url": "http://youtube.com/meuvideobacana"
 *	    }   
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "midia": {...}
 * }
 */
router.post('/video', function (req, res) {
    if (req.body.midia) {
        midiaService.gravaVideo(req.fotografo.id, req.body.midia, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Mídia não informada!" });
        return;
    }
});

/**
 * @api {post} /api/midias/foto GravaFoto
 * @apiDescription Grava uma foto na midia do fotografo
 * @apiName GravaFoto
 * @apiGroup Midia 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "--ARQUIVO--": "{}",
 *      "file": {} 
 *      "descricao": ""   
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "midia": {...}
 * }
 */
router.post('/foto', function (req, res) {
    var file = null;

    if (req.files) {
        file = req.files.file;
    }

    midiaService.gravaFoto(req.fotografo.id, req.body, file, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {delete} /api/midias/:id ExcluiMidiaPorFotografo
 * @apiDescription Exclui uma mídia por fotografo
 * @apiName ExcluiMidiaPorFotografo
 * @apiGroup Midia 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.delete('/:id', function (req, res) {
    midiaService.excluiMidiaDoFotografo(req.fotografo.id, req.params.id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;