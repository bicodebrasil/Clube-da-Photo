/* global __dirDomain */
var express = require('express');
var router = express.Router();
var fotografoService = require(__dirDomain + 'services/fotografoService');
var filtroToken = require('../middlewares/validaToken');

/**
 * @api {post} /api/fotografo Cadastro
 * @apiDescription Cadastra um novo Fotografo
 * @apiName Cadastro
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "fotografo":{
 *           "nome": "Roberto Teste 2",
 *           "nome_exibicao": "Roberto",
 *           "descricao": "Meu nome é Roberto e tiro fotos",
 *           "is_empresa": false,
 *           "site": "www.roberto.com.br",
 *           "foto_perfil_url": "",
 *           "facebook_id": "",
 *           "facebook_access_token": "",
 *           "facebook_expiration_date": "",
 *           "sexo_id": 1,
 *           "email": "reoberto@hotmail.com",
 *           "telefone": "1234-1234",
 *           "celular": "12345-1234",
 *           "is_whatsapp": true,
 *           "ano_inico_trabalho": 2016,
 *           "senha": "123456",
 *           "pais_id": 1,
 *           "estado_id": 26,
 *           "cep": "09781-220",
 *           "cidade_id": 5252,
 *           "bairro": "Meu bairro",
 *           "rua": "Minha rua",
 *           "numero": 123,
 *           "complemento": "Meu complemento",
 *           "facebook_url": "",
 *           "instagram_url": "",
 *           "youtube_url": "",
 *           "vimeo_url": "",
 *           "twitter_url": "",
 *           "linkedin_url": "",
 *           "google_plus_url": "",
 *           "categorias": [1,5,6,3],
 *           "profissoes": [2,3]
 *      }
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "fotografo": {...}
 * }
 */
router.post('/', function (req, res) {
    if (req.body.fotografo) {
        fotografoService.cadastraFotografo(req.body.fotografo, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Fotografo não enviado!" });
        return;
    }
});

/**
 * @api {post} /api/fotografo/verifica/email VerficaEmail
 * @apiDescription Verfica o email do fotografo
 * @apiName VerficaEmail
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "email": ""   
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "existe": false
 * }
 */
router.post('/verifica/email', function (req, res) {
    if (req.body.email) {
        fotografoService.verficaUsername(req.body.email, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Email não informado!" });
        return;
    }
});

/**
 * @api {get} /api/fotografo/busca/:id BuscaFotografo
 * @apiDescription Devolve um Fotografo pelo Id
 * @apiName BuscaFotografo
 * @apiGroup Fotografo 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "Fotografo": {...}
 * }
 */
router.get('/busca/:id', function (req, res) {
    fotografoService.buscaFotografo(req.params.id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {post} /api/fotografo/listagem ListagemDeFotografos
 * @apiDescription Devolve a uma listagem de Fotografos com base no filtro
 * @apiName ListagemDeFotografos
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "filtro": {
 *          "profissoes": [1, 2],
 *          "categorias": [1, 2, 3],
 *          "cidade": 1,
 *          "estado": 1,
 *          "sexo": 1,
 *          "proximidade": 1, //KMs
 *          "latitude": "37.7891",
 *          "longitude": "122.7832",
 *          "fotografo_id": 0
 *      },
 *      "paginacao": {
 *          "pagina": 1,
 *          "total_registros": 30
 *      }
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "lista": [{...}]
 * }
 */
router.post('/listagem', function (req, res) {
    fotografoService.listaFotografos(req.body.filtro, req.body.paginacao, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {get} /api/fotografo/facebook/:userID BuscarPorFacebookId
 * @apiDescription Buscar um Fotografo pelo id do facebook
 * @apiName BuscarPorFacebookId
 * @apiGroup Usuario 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "fotografo": {...}
 * }
 */
router.get('/facebook/:userID', function (req, res) {
    fotografoService.buscarPorFacebookId(req.params.userID, function (erro, resp) {
        if (erro) {
            res.status(erro.error_code).json(erro);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

router.use(filtroToken.validaToken);

/**
 * @api {put} /api/fotografo AtualizaCadastro
 * @apiDescription Atualiza os dados do Fotografo
 * @apiName AtualizaCadastro
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "fotografo": {...}    
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.put('/', function (req, res) {
    if (req.body.fotografo) {
        fotografoService.atualizaFotografo(req.fotografo.id, req.body.fotografo, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Fotografo não enviado!" });
        return;
    }
});

/**
 * @api {post} /api/fotografo/foto/perfil AtualizaFotoPerfil
 * @apiDescription Atualiza a foto de perfil do fotografo
 * @apiName AtualizaFotoPerfil
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "--ARQUIVO--": "{}",
 *      "file": {}    
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "fotografo": {...}
 * }
 */
router.post('/foto/perfil', function (req, res) {
    var file = null;

    if (req.files) {
        file = req.files.file;
    }

    fotografoService.atualizaFotoPerfil(req.fotografo.id, file, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {delete} /api/fotografo/foto/perfil ExcluiFotoPerfil
 * @apiDescription ExcluiFotoPerfil a foto de perfil do fotografo
 * @apiName ExcluiFotoPerfil
 * @apiGroup Fotografo 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200
 * }
 */
router.delete('/foto/perfil', function (req, res) {
    fotografoService.apagaFotoPerfil(req.fotografo.id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {post} /api/fotografo/favoritos ListagemDeFavoritos
 * @apiDescription Devolve a uma listagem de Favpritos com base no Fotografo
 * @apiName ListagemDeFavoritos
 * @apiGroup Fotografo 
 * 
 * @apiParamExample {json} Request-Example:
 * {
 *      "paginacao": {
 *          "pagina": 1,
 *          "total_registros": 30
 *      }
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "lista": [{...}]
 * }
 */
router.post('/favoritos', function (req, res) {
    fotografoService.listaFavoritos(req.fotografo.id, req.fotografo.geo_latitude, req.fotografo.geo_longitude, req.body.paginacao, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

/**
 * @api {get} /api/fotografo/usuariologado/busca/:id BuscaFotografoUsuarioLogado
 * @apiDescription Devolve um Fotografo pelo Id
 * @apiName BuscaFotografoUsuarioLogado
 * @apiGroup Fotografo 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "Fotografo": {...}
 * }
 */
router.get('/usuariologado/busca/:id', function (req, res) {
    fotografoService.buscaFotografoUsuarioLogado(req.params.id, req.fotografo.id, function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;