/* global __dirDomain */
var express = require('express');
var cidadeService = require(__dirDomain + 'services/cidadeService');
var router = express.Router();

/**
 * @api {get} /api/cidades/:estado ListaCidades
 * @apiDescription Devolve a listagem de cidades
 * @apiName ListaCidades
 * @apiGroup Cidades 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "estados": [
 *          {
 *              "id": 1,
 *              "nome": "Acrelândia",
 *              "estado_id": 1
 *          },
 *          {
 *              "id": 2,
 *              "nome": "Assis Brasil",
 *              "estado_id": 1
 *          }
 *      ]
 * }
 */
router.get('/:estado', function (req, res) {
    if (req.params.estado) {
        cidadeService.listagemDeCidades(req.params.estado, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json("Estado não informado!");
        return;
    }
});

module.exports = router;