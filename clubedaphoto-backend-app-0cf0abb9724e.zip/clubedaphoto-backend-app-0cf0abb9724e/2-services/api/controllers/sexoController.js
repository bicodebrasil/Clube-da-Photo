/* global __dirDomain */
var express = require('express');
var sexoService = require(__dirDomain + 'services/sexoService');
var router = express.Router();

/**
 * @api {get} /api/sexos ListaSexos
 * @apiDescription Devolve a listagem de sexos
 * @apiName ListaSexos
 * @apiGroup Sexos 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "sexo": [
 *          {
 *              "id": 1,
 *              "text": "Masculino"
 *          }
 *      ]
 * }
 */
router.get('/', function (req, res) {
    sexoService.listagemDeSexos(function (err, resp) {
        if (err) {
            res.status(err.error_code).json(err);
            return;
        }

        res.status(resp.status_code).json(resp);
        return;
    });
});

module.exports = router;