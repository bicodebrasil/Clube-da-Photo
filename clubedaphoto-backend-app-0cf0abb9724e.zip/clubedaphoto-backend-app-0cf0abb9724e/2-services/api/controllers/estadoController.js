/* global __dirDomain */
var express = require('express');
var estadoService = require(__dirDomain + 'services/estadoService');
var router = express.Router();

/**
 * @api {get} /api/estados/:pais ListaEstados
 * @apiDescription Devolve a listagem de estados
 * @apiName ListaEstados
 * @apiGroup Estados 
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "status_code": 200,
 *      "estados": [
 *          {
 *              "id": 1,
 *              "nome": "Acre",
 *              "uf": "AC",
 *              "pais_id": 1
 *          },
 *          {
 *              "id": 2,
 *              "nome": "Alagoas",
 *              "uf": "AL",
 *              "pais_id": 1
 *          }
 *      ]
 * }
 */
router.get('/:pais', function (req, res) {
    if (req.params.pais) {
        estadoService.listagemDeEstados(req.params.pais, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json("País não informado!");
        return;
    }
});

module.exports = router;