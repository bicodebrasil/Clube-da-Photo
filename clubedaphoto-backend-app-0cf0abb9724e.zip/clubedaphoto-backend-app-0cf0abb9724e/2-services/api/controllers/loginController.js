/* global __dirDomain */
var express = require('express');
var loginService = require(__dirDomain + 'services/loginService');
var router = express.Router();

/**
 * @api {post} /api/login LoginEmail
 * @apiDescription Faz login apartir do Email
 * @apiName LoginEmail
 * @apiGroup Login 
 *
 * @apiParamExample {json} Request-Example:
 * {
 *      "email": number,
 *      "senha": string
 * }
 * 
 * @apiSuccessExample {json} Success-Response:
 * HTTP/1.1 200 OK
 * {
 *      "fotografo": {...},
 *      "status_code: 200
 * }
 */
router.post('/', function (req, res) {
    if (req.body.email && req.body.senha) {
        loginService.autenticarPorEmail(req.body.email, req.body.senha, function (err, resp) {
            if (err) {
                res.status(err.error_code).json(err);
                return;
            }

            res.status(resp.status_code).json(resp);
            return;
        });
    } else {
        res.status(400).json({ error_code: 400, error_msg: "Email ou senha não informados!" });
        return;
    }
});

module.exports = router;