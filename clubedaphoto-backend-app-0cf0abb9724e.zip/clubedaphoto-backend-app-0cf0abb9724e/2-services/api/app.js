/* global __dirDomain */
var express = require('express');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var multipart = require('connect-multiparty');
var cors = require('cors');
var app = express();
__dirDomain = __dirname + '/../../3-domain/';
var env_ambiente = process.argv[2] || 'test';

//
// Configuracao dos Requests do app
//
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(bodyParser.json({ type: 'application/*+json' }));
app.use(bodyParser.raw({ type: 'application/vnd.custom-type' }));
app.use(bodyParser.text({ type: 'text/html' }));
app.use(multipart());

var allowsCors = function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'OPTIONS,GET,POST,PUT,DELETE');
    res.header("Access-Control-Allow-Headers", "Content-Type, token");
    res.header("Access-Control-Allow-Credentials", "true");

    if ('OPTIONS' == req.method) {
        return res.sendStatus(200);
    }
    next();
};
app.use(allowsCors);

// ======================================================================
// Rotas / Controllers
// ======================================================================
app.use('/api/login', require('./controllers/loginController'));
app.use('/api/categorias', require('./controllers/categoriaController'));
app.use('/api/profissoes', require('./controllers/profissaoController'));
app.use('/api/paises', require('./controllers/paisController'));
app.use('/api/estados', require('./controllers/estadoController'));
app.use('/api/cidades', require('./controllers/cidadeController'));
app.use('/api/fotografo', require('./controllers/fotografoController'));
app.use('/api/midias', require('./controllers/midiaController'));
app.use('/api/sexos', require('./controllers/sexoController'));
app.use('/api/favorito', require('./controllers/favoritoController'));
app.use('/api/marketing', require('./controllers/marketingController'));
app.use('/api/feedback', require('./controllers/feedbackController'));

var debug = require('debug')('clubedaphoto:server');
var http = require('http');
var port = 7001;
app.set('port', port);
process.env.TZ = 'America/Sao_Paulo';

// ===========================================================
// Start o node em um unico processo em 1 processador
// ===========================================================
var server = http.createServer(app);
server.listen(port);
server.on('error', onError);
server.on('listening', onListening);
// ===========================================================

// ===========================================================
// Ouvinte de eventos para o servidor HTTP evento "erro".
// ===========================================================
function onError(error) {
	if (error.syscall !== 'listen') {
		throw error;
	}

	var bind = typeof port === 'string' ? 'Pipe ' + port : 'Port ' + port;

	// handle specific listen errors with friendly messages
	switch (error.code) {
		case 'EACCES':
			console.error(bind + ' requer privilégios elevados');
			process.exit(1);
			break;
		case 'EADDRINUSE':
			console.error(bind + ' já está em uso');
			process.exit(1);
			break;
		default:
			throw error;
	}
}

// ===========================================================
// Ouvinte de eventos para o servidor HTTP "escuta" do evento.
// ===========================================================
// 
function onListening() {
	console.log();
	console.log(" -> Servidor :  Clube da Photo [API] Iniciado...");
	console.log(" -> Porta    : ", port);
	console.log(" -> Ambiente : ", env_ambiente);
	console.log();
}