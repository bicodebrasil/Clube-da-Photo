var fotografoService = require(__dirDomain + 'services/fotografoService');

exports.validaToken = function (req, res, next) {
    if (req.headers['token']) {
        var tokenString = req.headers['token'];

        fotografoService.buscaPorToken(tokenString, function (err, retorno) {
            if (err) {
                console.log("[ # ] Pedido negado ao TOKEN :   ", tokenString);
                console.log("[ # ] Pedido negado    err   :   ", err);
                res.status(err.error_code).json({ error_code: err.error_code, error_msg: "Token invalido!" });
                return;
            } else if (retorno.fotografo.is_ativo === false) {
                res.status(401).json({ error_code: 401, error_msg: "Usuário inativo!" });
            } else {
                req.fotografo = retorno.fotografo;
                next();
                return;
            }
        });
    } else {
        res.status(406).json({ error_code: 406, error_msg: "Token nao informado!" });
        return;
    }
};