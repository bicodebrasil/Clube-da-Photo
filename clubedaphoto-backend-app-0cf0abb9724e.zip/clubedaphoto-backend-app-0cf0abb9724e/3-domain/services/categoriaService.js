var FotografoCategoria = require('../models/_context').fotografoCategoria;
var Categoria = require('../models/_context').categoria;

exports.buscaCategoriasPorFotografo = function (_fotografoId, callback) {
    listaPorFotografo(_fotografoId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        devolveListaCategorias(resp.categorias, function (error, lista) {
            if (error) {
                callback(error);
                return;
            }

            callback(null, lista);
            return;
        });
    });
};

exports.listagemDeCategorias = function (callback) {
    listaTodas(function (err, lista) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, lista);
        return;
    });
};

exports.gravaListaCategorias = function (_fotografoId, _listaCategorias, callback) {
    var retorno = [];
    var itensLidos = 0;
    if (_listaCategorias !== null) {
        _listaCategorias.forEach(function (_categoriaId) {
            var categoria = {
                categoria_id: _categoriaId,
                fotografo_id: _fotografoId
            };

            createCategoriaPorFotografo(categoria, function (err, resp) {
                if (err) {
                    callback(err);
                    return;
                }

                retorno.push(resp.fotografoCategoria.categoria_id);
                itensLidos++;
                if (itensLidos === _listaCategorias.length) {
                    callback(null, { status_code: 200, categoriasIds: retorno });
                    return;
                }
            });
        }, this);
    } else {
        callback(null, { status_code: 200, categorias: retorno });
        return;
    }
};

exports.gravaCategoriaPorFotografo = function (_categoria, callback) {
    createCategoriaPorFotografo(_categoria, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
        return;
    });
};

exports.exlcuiCategoriaPorFotografo = function (_fotografoId, _categoriaId, callback) {
    deleteCategoriaPorFotografo(_fotografoId, _categoriaId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
        return;
    });
};

function devolveListaCategorias(_listaIds, callback) {
    var retorno = [];
    var itensLidos = 0;
    if (_listaIds !== null) {
        _listaIds.forEach(function (item) {
            buscaCategoriaPoId(item.categoria_id, function (err, resp) {
                if (err) {
                    callback(err);
                    return;
                }

                retorno.push(resp.categoria);
                itensLidos++;
                if (itensLidos === _listaIds.length) {
                    callback(null, { status_code: 200, categorias: retorno });
                    return;
                }
            });
        }, this);
    } else {
        callback(null, { status_code: 200, categorias: retorno });
        return;
    }
}

function listaPorFotografo(_fotografoId, callback) {
    FotografoCategoria.findAll({
        where: {
            fotografo_id: _fotografoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, categorias: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaCategoriaPoId(_categoriaId, callback) {
    Categoria.findOne({
        where: {
            id: _categoriaId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, categoria: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function listaTodas(callback) {
    Categoria.findAll()
        .then(function (resp) {
            callback(null, { status_code: 200, categorias: resp });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}

function createCategoriaPorFotografo(_categoria, callback) {
    FotografoCategoria.create(_categoria)
        .then(function (resp) {
            callback(null, { status_code: 200, fotografoCategoria: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function deleteCategoriaPorFotografo(_fotografoId, _categoriaId, callback) {
    FotografoProfissao.destroy({
        where: {
            fotografo_id: _fotografoId,
            categoria_id: _categoriaId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200 });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}