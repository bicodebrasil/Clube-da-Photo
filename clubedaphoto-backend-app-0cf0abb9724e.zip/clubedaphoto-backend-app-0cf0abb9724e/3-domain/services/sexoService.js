var sexo = require('../enums/sexo').sexo;

exports.listagemDeSexos = function (callback) {
    var retorno = [];

    sexo.enums.forEach(function (sexo) {
        var item = {
            id: sexo.value,
            text: sexo.key
        };
        retorno.push(item);
    }, this);

    callback(null, { status_code: 200, list: retorno });
};