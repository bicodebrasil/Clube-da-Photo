var Anuncio = require('../models/_context').anuncio;
var imagemService = require('../services/imagemService');
var env_ambiente = 'development';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}
var pathAmbiente = require('../../4-infra/config/config.json')[env_ambiente].path;

exports.listagemDeTodos = function (callback) {
    listaTodos(function (err, lista) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, lista);
        return;
    });
};

exports.listagemPorCategoria = function (_categoriaId, callback) {
    listaPorCategoria(_categoriaId, function (err, lista) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, lista);
        return;
    });
};

exports.adicionaAnuncio = function (_anuncio, _file, callback) {
    if (_file !== null && _file !== undefined) {
        var date = new Date();
        var stringDate = date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
        var pathFile = pathAmbiente + "/anuncios/" + stringDate + "_" + _file.name;
        imagemService.gravaImagem(_file, pathFile, function (error, resp) {
            if (error) {
                callback(error);
                return;
            }

            _anuncio.foto_anuncio_path = resp.path;
            _anuncio.foto_anuncio_url = resp.url;

            create(_anuncio, function (err, obj) {
                if (err) {
                    callback(err);
                    return;
                }

                callback(null, obj);
            });
        });
    } else {
        callback({ error_code: 500, error_msg: "Imagem não enviada!" });
    }
};

function listaTodos(callback) {
    Anuncio.findAll()
        .then(function (resp) {
            callback(null, { status_code: 200, anuncios: resp });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}

function listaPorCategoria(_categoriaId, callback) {
    Anuncio.findAll({
        where: {
            categoria_id: _categoriaId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, anuncios: resp });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}

function create(_anuncio, callback) {
    Anuncio.create(_anuncio)
        .then(function (resp) {
            callback(null, { status_code: 200, anuncio: resp.dataValues });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}

function pad2(n) { return n < 10 ? '0' + n : n; }