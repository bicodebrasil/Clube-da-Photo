var dbox = require('../../dropbox_config.js');
var fs = require('fs');
var resolver = require("resolver");
// var ds = require('../services/dboxService');

exports.upload = function (path, data, callback) {
    dbox.put(path, data, function (code, resp) {
        if (code !== 200) {
            callback({ error_code: code, error_msg: resp });
            return;
        }

        callback(null, { uploadDropBox: resp, status_code: 200 });
        return;
    });
};

exports.delete = function (path, callback) {
    dbox.rm(path, function (code, resp) {
        if (code !== 200) {
            callback({ error_code: code, error_msg: resp });
            return;
        }

        callback(null, { deleteDropBox: resp, status_code: 200 });
        return;
    });
};

exports.getUrl = function (path, callback) {
    var caminho = path.replace("/", "");
    dbox.shares(caminho, function (code, resp) {
        if (code !== 200) {
            callback({ error_code: code, error_msg: resp });
            return;
        }

        url(resp.url, function (err, url) {
            if (err) {
                callback({ error_code: 500, error_msg: err });
                return;
            }

            callback(null, { url: url, status_code: 200 });
            return;
        });
    });
};

function url(_url, callback) {
    resolver.resolve(_url, function (err, url) {
        var pos = url.lastIndexOf("?");
        var fim = url.slice(pos);
        url = url.replace(fim, "?raw=1");
        callback(null, url);
        return;
    });
}

exports.buffer = function (file, callback) {
    fs.readFile(file, function (err, data) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { buff: new Buffer(data), status_code: 200 });
        return;
    });
};