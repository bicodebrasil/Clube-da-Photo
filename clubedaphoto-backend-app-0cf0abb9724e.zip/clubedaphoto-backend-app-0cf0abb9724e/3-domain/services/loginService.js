var fotografoService = require('../services/fotografoService');

exports.autenticarPorEmail = function (_email, _pass, callback) {
    fotografoService.login(_email, _pass, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, resp);
        return;
    });
};