var Estado = require('../models/_context').estado;

exports.listagemDeEstados = function (paisId, callback) {
    listaPorPais(paisId, function (err, lista) {
        if (err) {
            callback(err);
        }

        callback(null, lista);
    });
};

function listaPorPais(paisId, callback) {
    Estado.findAll({
        where: {
            pais_id: paisId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, estados: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

exports.buscaPorId = function (id, callback) {
    Estado.findOne({
        where: {
            id: id
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, estado: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
};