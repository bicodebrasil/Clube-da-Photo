var Cidade = require('../models/_context').cidade;

exports.listagemDeCidades = function (estadoId, callback) {
    listaPorEstado(estadoId, function (err, lista) {
        if (err) {
            callback(err);
        }

        callback(null, lista);
    });
};

function listaPorEstado(estadoId, callback) {
    Cidade.findAll({
        where: {
            estado_id: estadoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, cidades: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

exports.buscaPorId = function (id, callback) {
    Cidade.findOne({
        where: {
            id: id
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, cidade: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
};