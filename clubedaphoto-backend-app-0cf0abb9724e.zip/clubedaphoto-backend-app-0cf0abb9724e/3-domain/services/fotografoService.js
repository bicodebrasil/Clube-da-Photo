var Fotografo = require('../models/_context').fotografo;
var imagemService = require('../services/imagemService');
var categoriaService = require('../services/categoriaService');
var profissaoService = require('../services/profissaoService');
var request = require('request');
var tokenService = require('../services/tokenService');
var env_ambiente = 'development';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}
var pathAmbiente = require('../../4-infra/config/config.json')[env_ambiente].path;
var context = require('../models/_context').context;
var midiaService = require('../services/midiaService');
var favoritoService = require('../services/favoritoService');
var cidadeService = require('../services/cidadeService');
var estadoService = require('../services/estadoService');

exports.login = function (_email, _pass, callback) {
    buscaPorEmailSenha(_email, _pass, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        profissaoService.buscaProfissoesPorFotografo(resp.fotografo.id, function (err, listaProf) {
            if (err) {
                callback(err);
                return;
            }

            resp.fotografo.profissoes = listaProf.profissoes;

            categoriaService.buscaCategoriasPorFotografo(resp.fotografo.id, function (e, listaCat) {
                if (e) {
                    callback(e);
                    return;
                }

                resp.fotografo.categorias = listaCat.categorias;

                midiaService.buscaMidiasPorFotografo(resp.fotografo.id, function (fail, listaMidias) {
                    if (fail) {
                        callback(fail);
                        return;
                    }

                    resp.fotografo.midias = listaMidias.midias;
                    callback(null, { status_code: 200, fotografo: resp.fotografo });
                });
            });
        });
    });
};

exports.cadastraFotografo = function (_fotografo, callback) {
    buscaLatitudeLongitudePorCep(_fotografo.cep, function (fail, geo) {
        if (fail) {
            callback(fail);
            return;
        }

        _fotografo.geo_latitude = geo.latitude;
        _fotografo.geo_longitude = geo.longitude;

        tokenService.gerarToken(function (f, token) {
            if (f) {
                callback(f);
                return;
            }

            _fotografo.token = token;

            criaFotografo(_fotografo, function (error, resp) {
                if (error) {
                    callback(error);
                    return;
                }

                categoriaService.gravaListaCategorias(resp.fotografo.id, _fotografo.categorias, function (err, lista) {
                    if (err) {
                        callback(err);
                        return;
                    }

                    resp.fotografo.categorias = lista.categoriasIds;

                    profissaoService.gravaListaProfissoes(resp.fotografo.id, _fotografo.profissoes, function (e, listaP) {
                        if (e) {
                            callback(e);
                            return;
                        }

                        resp.fotografo.profissoes = listaP.profissoesIds;
                        callback(null, resp);
                        return;
                    });
                });
            });
        });
    });
};

exports.apagaFotoPerfil = function (_fotografoId, callback) {
    buscaPorId(_fotografoId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        imagemService.excluiImagem(resp.fotografo.foto_perfil_path, function (e, sucess) {
            if (e) {
                callback(e);
                return;
            }

            resp.fotografo.foto_perfil_path = "";
            resp.fotografo.foto_perfil_url = "";

            atualizaFotografo(resp.fotografo, function (error, r) {
                if (error) {
                    callback(error);
                    return;
                }

                callback(null, r);
                return;
            });
        });
    });
};

exports.atualizaFotoPerfil = function (_fotografoId, _file, callback) {
    if (_file) {
        buscaPorId(_fotografoId, function (err, resp) {
            if (err) {
                callback(err);
                return;
            }

            if (resp.fotografo.foto_perfil_path === null || resp.fotografo.foto_perfil_path === "") {
                var date = new Date();
                var stringDate = date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
                var pathFile = pathAmbiente + "/fotografos/" + _fotografoId + "/perfil/" + stringDate + "_" + _file.name;

                var tamanho = require(__dirname + '/../../4-infra/config/config.json')[env_ambiente].imagem.menor;
                imagemService.resizeImage(_file.path, tamanho, function (fl, pathMenor) {
                    if (fl) {
                        callback(fl);
                        return;
                    }

                    var _fileMenor = {
                        path: pathMenor
                    };
                    imagemService.gravaImagem(_fileMenor, pathFile, function (e, drop) {
                        if (e) {
                            callback(e);
                            return;
                        }

                        resp.fotografo.foto_perfil_path = drop.path;
                        resp.fotografo.foto_perfil_url = drop.url;

                        atualizaFotografo(resp.fotografo, function (error, r) {
                            if (error) {
                                callback(error);
                                return;
                            }

                            callback(null, r);
                            return;
                        });
                    });
                });
            } else {
                imagemService.excluiImagem(resp.fotografo.foto_perfil_path, function (e, sucess) {
                    if (e) {
                        console.log(e);
                    }

                    var date = new Date();
                    var stringDate = date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
                    var pathFile = pathAmbiente + "/fotografos/" + _fotografoId + "/perfil/" + stringDate + "_" + _file.name;

                    var tamanho = require(__dirname + '/../../4-infra/config/config.json')[env_ambiente].imagem.menor;
                    imagemService.resizeImage(_file.path, tamanho, function (fl, pathMenor) {
                        if (fl) {
                            callback(fl);
                            return;
                        }

                        var _fileMenor = {
                            path: pathMenor
                        };
                        imagemService.gravaImagem(_fileMenor, pathFile, function (fail, drop) {
                            if (fail) {
                                callback(fail);
                                return;
                            }

                            resp.fotografo.foto_perfil_path = drop.path;
                            resp.fotografo.foto_perfil_url = drop.url;

                            atualizaFotografo(resp.fotografo, function (error, r) {
                                if (error) {
                                    callback(error);
                                    return;
                                }

                                callback(null, r);
                                return;
                            });
                        });
                    });
                });
            }
        });
    } else {
        callback({ error_code: 400, error_msg: "Arquivo não enviado!" });
        return;
    }
};

exports.buscaPorToken = function (_token, callback) {
    Fotografo.findOne({
        where: {
            token: _token
        }
    })
        .then(function (_usuario) {
            if (_usuario === null) {
                callback({ error_code: 401 });
                return null;
            } else {
                callback(null, { status_code: 200, fotografo: _usuario.dataValues });
                return null;
            }
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
};

exports.atualizaFotografo = function (_fotografoId, _fotografo, callback) {
    buscaLatitudeLongitudePorCep(_fotografo.cep, function (e, geo) {
        if (e) {
            callback(e);
            return;
        }

        _fotografo.id = _fotografoId;
        _fotografo.geo_latitude = geo.latitude;
        _fotografo.geo_longitude = geo.longitude;

        atualizaFotografo(_fotografo, function (err, resp) {
            if (err) {
                callback(err);
                return;
            }

            callback(null, resp);
            return;
        });
    });
};

exports.listaFotografos = function (_filtro, _paginacao, callback) {
    montaQuery(_filtro, _paginacao, function (error, retorno) {
        if (error) {
            callback(error);
            return;
        }

        executaQuerySelect(retorno.query, function (err, resp) {
            if (err) {
                callback(err);
                return;
            }

            devolvePaginacao(retorno.queryCount, _paginacao, function (fail, paginacao) {
                if (fail) {
                    callback(fail);
                    return;
                }

                montaListaRetorno(resp.lista, _filtro.fotografo_id, function (e, lista) {
                    if (e) {
                        callback(e);
                        return;
                    }

                    lista.paginacao = paginacao;
                    callback(null, lista);
                });
            });
        });
    });
};

exports.verficaUsername = function (_username, callback) {
    buscaPorEmail(_username, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        var existe = false;

        if (resp.fotografo !== null) {
            existe = true;
        }

        callback(null, { status_code: 200, existe: existe });
    });
};

exports.listaFavoritos = function (_fotografoId, _latitudeFotografo, _longitudeFotografo, _paginacao, callback) {
    montaQueryFavoritos(_fotografoId, _latitudeFotografo, _longitudeFotografo, _paginacao, function (error, retorno) {
        if (error) {
            callback(error);
            return;
        }

        executaQuerySelect(retorno.query, function (err, resp) {
            if (err) {
                callback(err);
                return;
            }

            devolvePaginacao(retorno.queryCount, _paginacao, function (fail, paginacao) {
                if (fail) {
                    callback(fail);
                    return;
                }

                montaListaRetorno(resp.lista, _fotografoId, function (e, lista) {
                    if (e) {
                        callback(e);
                        return;
                    }

                    lista.paginacao = paginacao;
                    callback(null, lista);
                });
            });
        });
    });
};

exports.buscaFotografo = function (_fotografoId, callback) {
    buscaPorId(_fotografoId, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        profissaoService.buscaProfissoesPorFotografo(resp.fotografo.id, function (err, listaProf) {
            if (err) {
                callback(err);
                return;
            }

            resp.fotografo.profissoes = listaProf.profissoes;

            categoriaService.buscaCategoriasPorFotografo(resp.fotografo.id, function (e, listaCat) {
                if (e) {
                    callback(e);
                    return;
                }

                resp.fotografo.categorias = listaCat.categorias;

                midiaService.buscaMidiasPorFotografo(resp.fotografo.id, function (fail, listaMidias) {
                    if (fail) {
                        callback(fail);
                        return;
                    }

                    resp.fotografo.midias = listaMidias.midias;

                    estadoService.buscaPorId(resp.fotografo.estado_id, function (estErr, estado) {
                        if (estErr) {
                            callback(estErr);
                            return;
                        }

                        if (estado.estado !== null) {
                            resp.fotografo.estado_nome = estado.estado.nome;
                        }

                        cidadeService.buscaPorId(resp.fotografo.cidade_id, function (cidErr, cidade) {
                            if (cidErr) {
                                callback(cidErr);
                                return;
                            }

                            if (cidade.cidade !== null) {
                                resp.fotografo.cidade_nome = cidade.cidade.nome;
                            }

                            delete resp.fotografo.facebook_id;
                            delete resp.fotografo.facebook_access_token;
                            delete resp.fotografo.facebook_expiration_date;
                            delete resp.fotografo.cep;
                            delete resp.fotografo.bairro;
                            delete resp.fotografo.rua;
                            delete resp.fotografo.numero;
                            delete resp.fotografo.complemento;
                            delete resp.fotografo.token;
                            delete resp.fotografo.data_criacao;
                            delete resp.fotografo.data_alteracao;

                            callback(null, { status_code: 200, fotografo: resp.fotografo });
                        });
                    });
                });
            });
        });
    });
};

exports.buscarPorFacebookId = function (_facebookId, callback) {
    buscaPorFacebookId(_facebookId, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        profissaoService.buscaProfissoesPorFotografo(resp.fotografo.id, function (err, listaProf) {
            if (err) {
                callback(err);
                return;
            }

            resp.fotografo.profissoes = listaProf.profissoes;

            categoriaService.buscaCategoriasPorFotografo(resp.fotografo.id, function (e, listaCat) {
                if (e) {
                    callback(e);
                    return;
                }

                resp.fotografo.categorias = listaCat.categorias;

                midiaService.buscaMidiasPorFotografo(resp.fotografo.id, function (fail, listaMidias) {
                    if (fail) {
                        callback(fail);
                        return;
                    }

                    resp.fotografo.midias = listaMidias.midias;
                    callback(null, { status_code: 200, fotografo: resp.fotografo });
                });
            });
        });
    });
};

function criaFotografo(_fotografo, callback) {
    Fotografo.create(_fotografo)
        .then(function (resp) {
            callback(null, { status_code: 200, fotografo: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaPorId(_id, callback) {
    Fotografo.findOne({
        where: {
            id: _id
        }
    })
        .then(function (_usuario) {
            if (_usuario === null) {
                callback({ error_code: 204 });
                return null;
            } else {
                callback(null, { status_code: 200, fotografo: _usuario.dataValues });
                return null;
            }
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function atualizaFotografo(_fotografo, callback) {
    Fotografo.update(_fotografo, {
        where: {
            id: _fotografo.id
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, fotografo: _fotografo });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaLatitudeLongitudePorCep(_cep, callback) {
    var url = 'http://maps.google.com/maps/api/geocode/json';

    var propertiesObject = { address: _cep, sensor: false };

    request({ url: url, qs: propertiesObject }, function (err, response, body) {
        if (err) {
            callback(err);
            return;
        }

        var retorno = JSON.parse(body);
        var geo = {
            latitude: "",
            longitude: ""
        };

        try {
            geo.latitude = retorno.results[0].geometry.location.lat;
            geo.longitude = retorno.results[0].geometry.location.lng;
        } catch (error) {
            console.log(error);
        }

        callback(null, geo);
        return;
    });
}

function buscaPorEmail(_username, callback) {
    Fotografo.findOne({
        where: {
            email: _username
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, fotografo: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function montaQuery(_filtro, _paginacao, callback) {
    // var _filtro = {
    //     profissoes: [1, 2],
    //     categorias: [1, 2, 3],
    //     cidade: 1,
    //     estado: 1,
    //     sexo: 1,
    //     proximidade: 1 //KMs
    // };

    // var _paginacao = {
    //     total_registros: 30,
    //     pagina: 1
    // };

    var distancia = "";
    var having = "";
    var order = "";

    if (_filtro.proximidade !== null && _filtro.proximidade !== 0 && _filtro.proximidade !== "") {
        distancia += " , (6371 * ACOS(COS(RADIANS(" + parseFloat(_filtro.latitude) + ")) * COS(RADIANS(f.geo_latitude)) * " +
            " COS(RADIANS(f.geo_longitude) - RADIANS(" + parseFloat(_filtro.longitude) + ")) + SIN(RADIANS(" +
            parseFloat(_filtro.latitude) + ")) * SIN(RADIANS(f.geo_latitude)))) AS distancia ";

        having += " HAVING distancia < " + _filtro.proximidade;
        order += " ORDER BY distancia ";
    }

    var query = " SELECT f.id, f.nome_exibicao, f.foto_perfil_url, c.nome as cidade, e.nome as estado, f.is_empresa " + distancia + " FROM tb_fotografo f " +
        "INNER JOIN tb_cidade c ON f.cidade_id = c.id INNER JOIN tb_estado e ON f.estado_id " +
        "= e.id ";

    var where = "";
    var possuiFiltro = false;
    var i = 0;

    if (_filtro.profissoes.length > 0) {
        possuiFiltro = true;
        query += "LEFT OUTER JOIN tb_fotografo_profissao fp ON f.id = fp.fotografo_id ";

        i = 0;
        where += " ( ";
        _filtro.profissoes.forEach(function (profissao) {
            i++;
            where += " fp.profissao_id = " + profissao;
            if (i !== _filtro.profissoes.length) {
                where += " OR ";
            }
        }, this);
        where += " ) ";
    }

    if (_filtro.categorias.length > 0) {
        possuiFiltro = true;
        query += "LEFT OUTER JOIN tb_fotografo_categoria fc ON f.id = fc.fotografo_id ";

        if (where !== "") {
            where += " AND ";
        }

        i = 0;
        where += " ( ";
        _filtro.categorias.forEach(function (categoria) {
            i++;
            where += " fc.categoria_id = " + categoria;
            if (i !== _filtro.categorias.length) {
                where += " OR ";
            }
        }, this);
        where += " ) ";
    }

    if (_filtro.cidade !== null && _filtro.cidade !== 0 && _filtro.cidade !== "") {
        possuiFiltro = true;
        if (where !== "") {
            where += " AND ";
        }

        where += " f.cidade_id = " + _filtro.cidade;
    }

    if (_filtro.estado !== null && _filtro.estado !== 0 && _filtro.estado !== "") {
        possuiFiltro = true;
        if (where !== "") {
            where += " AND ";
        }

        where += " f.estado_id = " + _filtro.estado;
    }

    if (_filtro.sexo !== null && _filtro.sexo !== 0 && _filtro.sexo !== "") {
        possuiFiltro = true;
        if (where !== "") {
            where += " AND ";
        }

        where += " f.sexo_id = " + _filtro.sexo;
    }

    if (possuiFiltro) {
        query += " WHERE " + where;
    }

    query += having + order;
    var qPaginacao = " LIMIT " + ((_paginacao.pagina - 1) * _paginacao.total_registros) + ", " + _paginacao.total_registros;
    var queryCount = " SELECT count(*) qtde FROM ( " + query + " ) as resultTable ; ";
    query += qPaginacao;

    callback(null, { query: query, queryCount: queryCount });
    return;
}

function devolvePaginacao(_queryCount, _paginacao, callback) {
    executaQuerySelect(_queryCount, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        var paginacao = {
            current_page: _paginacao.pagina,
            total: resp.lista[0].qtde,
            to: (_paginacao.pagina) * _paginacao.total_registros,
            from: ((_paginacao.pagina) * _paginacao.total_registros) - _paginacao.total_registros + 1,
            last_page: Math.ceil(resp.lista[0].qtde / _paginacao.total_registros),
            per_page: _paginacao.total_registros
        };

        callback(null, paginacao);
        return;
    });
}

function executaQuerySelect(query, callback) {
    context.query(query, { type: context.QueryTypes.SELECT })
        .then(function (resp) {
            callback(null, { status_code: 200, lista: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 502, error_msg: err });
            return null;
        });
}

function montaListaRetorno(_listaFotografos, _fotografoId, callback) {
    var retorno = [];
    if (_listaFotografos.length > 0) {
        var itensLidos = 0;
        _listaFotografos.forEach(function (fotografo) {
            profissaoService.buscaProfissoesPorFotografo(fotografo.id, function (error, resp) {
                if (error) {
                    callback(error);
                    return;
                }

                fotografo.profissoes = resp.profissoes;

                if (_fotografoId !== null && _fotografoId !== 0 && _fotografoId !== "" && _fotografoId !== undefined) {
                    favoritoService.buscaFotografoFavorito(_fotografoId, fotografo.id, function (err, suc) {
                        if (err) {
                            callback(err);
                            return;
                        }

                        if (suc.fotografoFavorito !== null) {
                            fotografo.is_favorito = true;
                        } else {
                            fotografo.is_favorito = false;
                        }

                        retorno.push(fotografo);
                        itensLidos++;
                        if (itensLidos === _listaFotografos.length) {
                            callback(null, { status_code: 200, lista: retorno });
                            return;
                        }
                    });
                } else {
                    retorno.push(fotografo);
                    itensLidos++;
                    if (itensLidos === _listaFotografos.length) {
                        callback(null, { status_code: 200, lista: retorno });
                        return;
                    }
                }
            });
        }, this);
    } else {
        callback(null, { status_code: 200, lista: retorno });
        return;
    }
}

function montaQueryFavoritos(_fotografoId, latitude, longitude, _paginacao, callback) {
    var distancia;

    if (!latitude || !longitude) {
        distancia = "";
    } else {
        distancia = " , (6371 * ACOS(COS(RADIANS(" + parseFloat(latitude) + ")) * COS(RADIANS(f.geo_latitude)) * " +
            " COS(RADIANS(f.geo_longitude) - RADIANS(" + parseFloat(longitude) + ")) + SIN(RADIANS(" +
            parseFloat(latitude) + ")) * SIN(RADIANS(f.geo_latitude)))) AS distancia ";
    }

    var query = " SELECT f.id, f.nome_exibicao, f.foto_perfil_url, c.nome as cidade, e.nome as estado, f.is_empresa " + distancia +
        " FROM tb_fotografo_favorito ff INNER JOIN tb_fotografo f ON ff.fotografo_favorito_id = f.id INNER " +
        " JOIN tb_cidade c ON f.cidade_id = c.id INNER JOIN tb_estado e ON f.estado_id = e.id ";

    var where = " WHERE ff.fotografo_id = " + _fotografoId;

    query += where;

    var qPaginacao = " LIMIT " + ((_paginacao.pagina - 1) * _paginacao.total_registros) + ", " + _paginacao.total_registros;
    var queryCount = " SELECT count(*) qtde FROM ( " + query + " ) as resultTable ; ";
    query += qPaginacao;

    callback(null, { query: query, queryCount: queryCount });
    return;
}

function buscaPorEmailSenha(_email, _pass, callback) {
    Fotografo.findOne({
        where: {
            email: _email,
            senha: _pass
        }
    })
        .then(function (_usuario) {
            if (_usuario === null) {
                callback({ error_code: 401, error_msg: 'Fotografo não encontrado!' });
                return null;
            } else if (_usuario.is_ativo === false) {
                callback({ error_code: 401, error_msg: 'Fotografo inativo!' });
                return null;
            } else {
                callback(null, { status_code: 200, fotografo: _usuario.dataValues });
                return null;
            }
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function pad2(n) { return n < 10 ? '0' + n : n; }

function buscaPorFacebookId(_facebookId, callback) {
    Fotografo.findOne({
        where: {
            facebook_id: _facebookId
        }
    })
        .then(function (_usuario) {
            if (_usuario === null) {
                callback({ error_code: 401, error_msg: 'Fotografo não encontrado!' });
                return null;
            } else if (_usuario.is_ativo === false) {
                callback({ error_code: 401, error_msg: 'Fotografo inativo!' });
                return null;
            } else {
                callback(null, { status_code: 200, fotografo: _usuario.dataValues });
                return null;
            }
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

exports.buscaFotografoUsuarioLogado = function (_fotografoId, _fotografoLogadoId, callback) {
    buscaPorId(_fotografoId, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        profissaoService.buscaProfissoesPorFotografo(resp.fotografo.id, function (err, listaProf) {
            if (err) {
                callback(err);
                return;
            }

            resp.fotografo.profissoes = listaProf.profissoes;

            categoriaService.buscaCategoriasPorFotografo(resp.fotografo.id, function (e, listaCat) {
                if (e) {
                    callback(e);
                    return;
                }

                resp.fotografo.categorias = listaCat.categorias;

                midiaService.buscaMidiasPorFotografo(resp.fotografo.id, function (fail, listaMidias) {
                    if (fail) {
                        callback(fail);
                        return;
                    }

                    resp.fotografo.midias = listaMidias.midias;

                    estadoService.buscaPorId(resp.fotografo.estado_id, function (estErr, estado) {
                        if (estErr) {
                            callback(estErr);
                            return;
                        }

                        if (estado.estado !== null) {
                            resp.fotografo.estado_nome = estado.estado.nome;
                        }

                        cidadeService.buscaPorId(resp.fotografo.cidade_id, function (cidErr, cidade) {
                            if (cidErr) {
                                callback(cidErr);
                                return;
                            }

                            if (cidade.cidade !== null) {
                                resp.fotografo.cidade_nome = cidade.cidade.nome;
                            }

                            favoritoService.buscaFotografoFavorito(_fotografoLogadoId, _fotografoId, function (favErr, suc) {
                                if (favErr) {
                                    callback(favErr);
                                    return;
                                }

                                if (suc.fotografoFavorito !== null) {
                                    resp.fotografo.is_favorito = true;
                                } else {
                                    resp.fotografo.is_favorito = false;
                                }

                                delete resp.fotografo.facebook_id;
                                delete resp.fotografo.facebook_access_token;
                                delete resp.fotografo.facebook_expiration_date;
                                delete resp.fotografo.cep;
                                delete resp.fotografo.bairro;
                                delete resp.fotografo.rua;
                                delete resp.fotografo.numero;
                                delete resp.fotografo.complemento;
                                delete resp.fotografo.token;
                                delete resp.fotografo.data_criacao;
                                delete resp.fotografo.data_alteracao;

                                callback(null, { status_code: 200, fotografo: resp.fotografo });
                            });
                        });
                    });
                });
            });
        });
    });
};