var FotografoMidia = require('../models/_context').fotografoMidia;
var tipoMidia = require('../enums/tipoMidia').tipoMidia;
var imagemService = require('../services/imagemService');
var env_ambiente = 'development';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}
var pathAmbiente = require('../../4-infra/config/config.json')[env_ambiente].path;

exports.gravaVideo = function (_fotografoId, _midia, callback) {
    _midia.fotografo_id = _fotografoId;
    _midia.tipo_id = tipoMidia['Vídeo'].value;
    create(_midia, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, resp);
        return;
    });
};

exports.gravaFoto = function (_fotografoId, _midia, _file, callback) {
    if (!_file) {
        callback({ error_code: 400, error_msg: "Arquivo não enviado!" });
        return;
    }

    _midia.fotografo_id = _fotografoId;
    _midia.tipo_id = tipoMidia['Foto'].value;

    var tamanho = require(__dirname + '/../../4-infra/config/config.json')[env_ambiente].imagem.padrao;
    imagemService.resizeImage(_file.path, tamanho, function (error, path) {
        if (error) {
            callback(error);
            return;
        }

        var date = new Date();
        var stringDate = date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
        var pathFile = pathAmbiente + "/fotografos/" + _fotografoId + "/midias/" + stringDate + "_" + _file.name;
        var padrao = {
            path: path
        };
        imagemService.gravaImagem(padrao, pathFile, function (err, resp) {
            if (err) {
                callback(err);
                return;
            }

            _midia.foto_original_path = resp.path;
            _midia.foto_original_url = resp.url;

            var tamanho = require(__dirname + '/../../4-infra/config/config.json')[env_ambiente].imagem.menor;
            imagemService.resizeImage(_file.path, tamanho, function (fl, pathMenor) {
                if (fl) {
                    callback(fl);
                    return;
                }

                var date = new Date();
                var stringDate = date.getFullYear().toString() + pad2(date.getMonth() + 1) + pad2(date.getDate()) + pad2(date.getHours()) + pad2(date.getMinutes()) + pad2(date.getSeconds());
                var pathFile = pathAmbiente + "/fotografos/" + _fotografoId + "/midias/" + stringDate + "_menor_" + _file.name;
                var menor = {
                    path: pathMenor
                };
                imagemService.gravaImagem(menor, pathFile, function (e, suc) {
                    if (e) {
                        callback(e);
                        return;
                    }

                    _midia.foto_menor_path = suc.path;
                    _midia.foto_menor_url = suc.url;

                    create(_midia, function (err, resp) {
                        if (err) {
                            callback(err);
                            return;
                        }

                        callback(null, resp);
                        return;
                    });
                });
            });
        });
    });
};

exports.excluiMidiaDoFotografo = function (_fotografoId, _midiaId, callback) {
    buscaMidiaDoFotografo(_fotografoId, _midiaId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        if (resp.fotografoMidia.tipo_midia === tipoMidia['Vídeo'].value) {
            excluiMidia(_fotografoId, _midiaId, function (error, resp) {
                if (error) {
                    callback(error);
                    return;
                }

                callback(null, resp);
                return;
            });
        } else {
            imagemService.excluiImagem(resp.fotografoMidia.foto_original_path, function (error, resp) {
                if (error) {
                    callback(error);
                    return;
                }

                imagemService.excluiImagem(resp.fotografoMidia.foto_menor_path, function (e, resp) {
                    if (e) {
                        callback(e);
                        return;
                    }

                    excluiMidia(_fotografoId, _midiaId, function (fail, resp) {
                        if (fail) {
                            callback(fail);
                            return;
                        }

                        callback(null, resp);
                        return;
                    });
                });
            });
        }
    });
};

exports.buscaMidiasPorFotografo = function (_fotografoId, callback) {
    buscaPorFotografo(_fotografoId, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        callback(null, resp);
    });
};

function create(_midia, callback) {
    FotografoMidia.create(_midia)
        .then(function (resp) {
            callback(null, { status_code: 200, fotografoMidia: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaMidiaDoFotografo(_fotografoId, _midiaId, callback) {
    FotografoMidia.findOne({
        where: {
            fotografo_id: _fotografoId,
            id: _midiaId
        }
    })
        .then(function (resp) {
            if (resp === null) {
                callback({ error_code: 400, error_msg: "Mídia não encontrada" });
                return null;
            } else {
                callback(null, { status_code: 200, fotografoMidia: resp.dataValues });
                return null;
            }
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function excluiMidia(_fotografoId, _midiaId, callback) {
    FotografoMidia.destroy({
        where: {
            id: _midiaId,
            fotografo_id: _fotografoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200 });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaPorFotografo(_fotografoId, callback) {
    FotografoMidia.findAll({
        where: {
            fotografo_id: _fotografoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, midias: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function pad2(n) { return n < 10 ? '0' + n : n; }