var Token = require('../models/_context').token;

/**
* Gera um novo token para um dispositivo ou usuario
*/
exports.gerarToken = function (callback) {
    criaToken(function (e, resp) {
        if (e) {
            callback(e);
            return;
        }

        registraToken(resp, function (err, ok) {
            if (err) {
                callback(err);
                return;
            }

            callback(null, resp);
            return;
        });
    });
};

function criaToken(callback) {
    montaToken(function (err, tokenReturn) {
        if (err) {
            callback(err);
            return;
        }

        buscaPorToken(tokenReturn, function (error, resp) {
            if (err) {
                callback(err);
                return;
            } else if (resp.token === null) {
                callback(null, tokenReturn);
                return;
            } else {
                criaToken(function (e, resp) {
                    if (e) {
                        callback(e);
                        return;
                    }

                    callback(null, resp);
                    return;
                });
            }
        });
    });
}

function montaToken(callback) {
    var Size = 100;
    var input = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    var tokenReturn = "";

    for (var i = 0; i <= Size; i++) {
        indexRandom = getRandomInt(1, input.length);
        tokenReturn += input.substring(indexRandom - 1, indexRandom);

        if (i === Size) {
            callback(null, tokenReturn);
            return;
        }
    }
}

function buscaPorToken(_token, callback) {
    Token.findOne({
        where: {
            token: _token
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, token: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function registraToken(_token, callback) {
    Token.create({
        token: _token
    })
        .then(function (resp) {
            callback(null, { status_code: 200, token: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function getRandomInt(min, max) {
    var rand = Math.floor(Math.random() * (max - min + 1)) + min;
    return rand;
}

// var getTokenByString = function (_token, callback) {
//     return Token.findOne({
//         where: {
//             token: _token
//         }
//     })
//         .then(function (resp) {
//             if (resp === null) {
//                 callback({ error_code: 204, error_msg: "Token nao Encontrado. [ " + _token + " ]" });
//             } else {
//                 callback(null, { token: resp.dataValues, status_code: 200 });
//             }
//         })
//         .catch(function (err) {
//             callback({ error_code: 401, error_msg: "Token nao Encontrado [ " + _token + " ] , " + err });
//         });
// };
// exports.getTokenByString = getTokenByStringMongo;

// function registrarToken(_token, _tipoToken, empresa_id, cliente_id, callback) {
//     var tok = {
//         token: _token,
//         tipo_token: _tipoToken,
//         empresa_id: empresa_id,
//         cliente_id: cliente_id
//     };

//     Token.create(tok)
//         .then(function (resp) {
//             callback(null, { status_code: 200, token: resp });
//         })
//         .catch(function (err) {
//             callback({ error_code: 502, error_msg: "Erro ao registrar o Token" });
//         });
// }
// exports.registrarToken = registrarTokenMongo;




// /**
//  * Retorna um número inteiro aleatório entre min (inclusive) e max (inclusive)
//  * Utilizando Math.round () lhe dará uma distribuição não uniforme!
//  */
// function getRandomInt(min, max) {
//     var rand = Math.floor(Math.random() * (max - min + 1)) + min;
//     return rand;
// }

// function deleteByToken(token, empresa_id, callback) {
//     Token.destroy({
//         where: {
//             token: token,
//             empresa_id: empresa_id
//         }
//     })
//         .then(function (resp) {
//             callback(null, { status_code: 200 });
//         })
//         .catch(function (err) {
//             callback({ error_code: 502, error_msg: err });
//         });
// }
// exports.deleteByToken = deleteByTokenMongo;

// exports.extractToken = function (_token, callback) {
//     getTokenByStringMongo(_token, function (err, resp) {
//         if (err) {
//             if (err.error_code == 204) {
//                 var id = 0;
//                 try {
//                     id = parseInt(crypto.descTexto(_token)) || 0;
//                 } catch (error) {
//                     console.log(_token);
//                     console.log(error);
//                     id = 0;
//                 }

//                 if (id > 0) {
//                     UsuarioCliente.findOne({
//                         where: {
//                             id: id
//                         }
//                     })
//                         .then(function (obj) {
//                             if (obj === null) {
//                                 callback({ error_code: 404, error_msg: "Usuario Cliente não encontrado!" });
//                             } else {
//                                 var usuarioCliente = obj.dataValues;
//                                 var _tokUsuarioCliente = {
//                                     empresa_id: usuarioCliente.empresa_id,
//                                     cliente_id: usuarioCliente.cliente_id,
//                                     usuarioCliente: usuarioCliente,
//                                     tipo_token: TipoToken.UsuarioCliente,
//                                     token: _token
//                                 };
//                                 callback(null, { status_code: 200, token: _tokUsuarioCliente });
//                             }
//                         })
//                         .catch(function (erro) {
//                             callback({ error_code: 401, error_msg: erro });
//                         });
//                 } else {
//                     callback({ error_code: 204, error_msg: "Token nao Encontrado." });
//                 }
//             } else {
//                 callback(err);
//             }
//         } else {
//             var tokenRet = resp;
//             if (tokenRet.token.tipo_token == TipoToken.Dispositivo.value) {
//                 Dispositivo.findOne({
//                     where: {
//                         token: _token
//                     }
//                 })
//                     .then(function (resp) {
//                         if (resp === null) {
//                             callback({ error_code: 404, error_msg: "Dispositivo não encontrado!" });
//                         } else {
//                             var dispositivo = resp.dataValues;
//                             var _tokDispositivo = {
//                                 empresa_id: dispositivo.empresa_id,
//                                 cliente_id: dispositivo.cliente_id,
//                                 dispositivo: dispositivo,
//                                 tipo_token: tokenRet.token.tipo_token,
//                                 token: tokenRet.token
//                             };
//                             callback(null, { status_code: 200, token: _tokDispositivo });
//                         }
//                     })
//                     .catch(function (err) {
//                         callback({ error_code: 401, error_msg: err });
//                     });
//             } else if (tokenRet.token.tipo_token == TipoToken.Usuario.value) {
//                 Usuario.findOne({
//                     where: {
//                         token: _token
//                     }
//                 })
//                     .then(function (resp) {
//                         if (resp === null) {
//                             callback({ error_code: 404, error_msg: "Usuario não encontrado!" });
//                         } else {
//                             var usuario = resp.dataValues;
//                             var _tokUser = {
//                                 empresa_id: usuario.empresa_id,
//                                 usuario: usuario,
//                                 tipo_token: tokenRet.token.tipo_token,
//                                 token: usuario.token
//                             };
//                             callback(null, { status_code: 200, token: _tokUser });
//                         }
//                     })
//                     .catch(function (err) {
//                         callback({ error_code: 401, error_msg: err });
//                     });
//             } else {
//                 callback({ error_code: 401, error_msg: "Tipo de token não identificado!" });
//             }
//         }
//     });
// };

// function getTokenByStringMongo(_token, callback) {
//     TokensMongo.findOne({ 'token': _token }, function (err, resp) {
//         if (err) {
//             callback({ error_code: 401, error_msg: "Token nao Encontrado [ " + _token + " ] , " + err });
//         } else if (resp === null) {
//             callback({ error_code: 204, error_msg: "Token nao Encontrado. [ " + _token + " ]" });
//         } else {
//             var token = resp._doc;
//             callback(null, { token: token, status_code: 200 });
//         }
//     });
// }

// function registrarTokenMongo(_token, _tipoToken, empresa_id, cliente_id, callback) {
//     var tokenObj = {
//         token: _token,
//         tipo_token: _tipoToken,
//         empresa_id: empresa_id,
//         cliente_id: cliente_id
//     };

//     Token.create(tokenObj)
//         .then(function (resp) {
//             TokensMongo.create(tokenObj, function (err, tokenNovo) {
//                 if (err) {
//                     callback({ error_code: 502, error_msg: err });
//                 } else {
//                     callback(null, { status_code: 200, token: resp });
//                 }
//             });
//         })
//         .catch(function (err) {
//             callback({ error_code: 502, error_msg: "Erro ao registrar o Token! " + err });
//         });
// }

// function deleteByTokenMongo(token, empresa_id, callback) {
//     Token.destroy({
//         where: {
//             token: token,
//             empresa_id: empresa_id
//         }
//     })
//         .then(function (resp) {
//             TokensMongo.remove({ 'token': token, 'empresa_id': empresa_id }, function (err, suc) {
//                 if (err) {
//                     callback({ error_code: 502, error_msg: err });
//                 } else {
//                     callback(null, { status_code: 200 });
//                 }
//             });
//         })
//         .catch(function (err) {
//             callback({ error_code: 502, error_msg: err });
//         });
// }

// exports.migraTokensParaMongo = function (callback) {
//     Sync(function () {
//         var tokens = [];
//         try {
//             tokens = listaTokens.sync(null);
//         } catch (error) {
//             console.log(error);
//         }

//         var i = 1;
//         tokens.forEach(function (element) {
//             var tokenMongo = {
//                 token: element.token,
//                 tipo_token: element.tipo_token,
//                 empresa_id: element.empresa_id,
//                 cliente_id: element.cliente_id
//             };

//             try {
//                 createMongo.sync(null, tokenMongo, i);
//                 i++;
//             } catch (error) {
//                 console.log(error);
//             }
//         }, this);

//         callback(null, "Salvo com sucesso!");
//     });
// };

// function listaTokens(callback) {
//     Token.findAll()
//         .then(function (tokens) {
//             callback(null, tokens);
//         })
//         .catch(function (err) {
//             callback(err);
//         });
// }

// function createMongo(token, i, callback) {
//     TokensMongo.update({ 'token': token.token }, token, { upsert: true }, function (err, tokenNovo) {
//         if (err) {
//             console.log(token);
//             callback(err);
//         } else {
//             if (tokenNovo.nModified === 0) {
//                 console.log("Token " + i + " salvo!");
//                 callback(null, true);
//             } else {
//                 console.log("Token Alterado! [ " + token.token + " ] ");
//                 callback(null, true);
//             }
//         }
//     });
// }

// exports.excluiTokensInutilizados = function (callback) {
//     Sync(function () {
//         var query = "SELECT * FROM (SELECT t.*, d.id AS disp_id, u.id AS user_id FROM tb_token t " +
//             " LEFT OUTER JOIN tb_dispositivo d ON t.token = d.token LEFT OUTER JOIN tb_usuario u ON " +
//             " t.token = u.token) AS tokens WHERE disp_id IS NULL AND user_id IS NULL";

//         var tokens = executaQuerySelect.sync(null, query);

//         tokens.lista.forEach(function (token) {
//             deleteByTokenMongo.sync(null, token.token, token.empresa_id);
//             console.log("Excluído: " + token.id);
//         }, this);

//         callback(null, { status_code: 200, msg: "Tokens excluídos com sucesso!" });
//     });
// };

// exports.extractTokenAdmin = function (_token, callback) {
//     UsuarioAdmin.findOne({
//         where: {
//             token: _token
//         }
// 				})
//         .then(function (resp) {
//             if (resp === null) {
//                 callback({ error_code: 404, error_msg: "Usuario Admin não encontrado!" });
//             } else {
//                 var usuario = resp.dataValues;
//                 var _tokUser = {
//                     usuario: usuario,
//                     token: usuario.token
//                 };
//                 callback(null, { status_code: 200, token: _tokUser });
//             }
//         })
//         .catch(function (err) {
//             callback({ error_code: 401, error_msg: err });
//         });
// };