var Feedback = require('../models/_context').feedback;
var statusEmail = require('../enums/statusEmail').statusEmail;
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
var env_ambiente = 'development';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}
var para = require('../../4-infra/config/config.json')[env_ambiente].email_para;

exports.criaFeedback = function (_feedback, callback) {
    var _html = _feedback.texto;
    criaEmail(_html, function (error, resp) {
        if (error) {
            _feedback.status_id = statusEmail['Não enviado'].value;
        } else {
            _feedback.status_id = statusEmail['Enviado'].value;
        }

        create(_feedback, function (err, obj) {
            if (err) {
                callback(err);
                return;
            }

            callback(null, obj);
        });
    });
};

// ========================================================================
// Configuracao do envio de Email
// cria um método de transporte reutilizável (abre pool de conexões SMTP)
// ========================================================================
var transport = nodemailer.createTransport((smtpTransport({
    host: 'smtp.zoho.com',
    port: '587',
    auth: { user: 'naoresponder@clubedaphoto.com.br', pass: '@clubedaphoto' },
    secureConnection: false,
    tls: true
})));

var from_padrao = "Clube da Photo ";

// ==========================================================================
// Array de objectos de qual caracter deve substituir seu par com acentos
// ==========================================================================
var specialChars = [
    { val: "a", let: "áàãâä" },
    { val: "e", let: "éèêë" },
    { val: "i", let: "íìîï" },
    { val: "o", let: "óòõôö" },
    { val: "u", let: "úùûü" },
    { val: "c", let: "ç" },
    { val: "a", let: "ÁÀÃÂÄ" },
    { val: "e", let: "ÉÈÊË" },
    { val: "i", let: "ÍÌÎÏ" },
    { val: "o", let: "ÓÒÕÔÖ" },
    { val: "u", let: "ÚÙÛÜ" },
    { val: "c", let: "Ç" },
    { val: "", let: "?!()" }
];

// ==========================================================================
// Função para substituir caractesres especiais.
// ==========================================================================
function replaceSpecialChars(str) {
    var $spaceSymbol = '';
    var regex;
    var returnString = str;
    for (var i = 0; i < specialChars.length; i++) {
        regex = new RegExp("[" + specialChars[i].let + "]", "g");
        returnString = returnString.replace(regex, specialChars[i].val);
        regex = null;
    }
    return returnString.replace(/\s/g, $spaceSymbol);
}

function criaEmail(_html, callback) {
    try {
        // Validacao do email
        var remetente = from_padrao + "<naoresponder@clubedaphoto.com.br>";

        // Configura o e-mail a ser enviado (data with unicode symbols)
        var mailOptions = {
            from: remetente,
            to: para,
            subject: "Feedback Clube da Photo",
            html: _html
        };

        // Envia o email
        transport.sendMail(mailOptions, function (error, response) {
            if (error) {
                callback({ error_code: 500, error_msg: error });
                return;
            }

            callback(null, { status_code: 200 });
        });
    } catch (ex) {
        console.log();
        console.log('[ ERRO ]  Erro ao enviar o Email : ', ex);
        console.log();
        callback({ error_code: 500, error_msg: ex });
    }
}

function create(_feedback, callback) {
    Feedback.create(_feedback)
        .then(function (resp) {
            callback(null, { status_code: 200, feedback: resp.dataValues });
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
        });
}