var FotografoProfissao = require('../models/_context').fotografoProfissao;
var Profissao = require('../models/_context').profissao;

exports.buscaProfissoesPorFotografo = function (_fotografoId, callback) {
    listaPorFotografo(_fotografoId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        devolveListaProfissoes(resp.profissoes, function (error, lista) {
            if (error) {
                callback(error);
                return;
            }

            callback(null, lista);
            return;
        });
    });
};

exports.listagemDeProfissoes = function (callback) {
    listaTodas(function (err, lista) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, lista);
        return;
    });
};

exports.gravaListaProfissoes = function (_fotografoId, _listaProfissoes, callback) {
    var retorno = [];
    var itensLidos = 0;
    if (_listaProfissoes !== null) {
        _listaProfissoes.forEach(function (_profissaoId) {
            var profissao = {
                profissao_id: _profissaoId,
                fotografo_id: _fotografoId
            };

            createProfissaoPorFotografo(profissao, function (err, resp) {
                if (err) {
                    callback(err);
                    return;
                }

                retorno.push(resp.fotografoProfissao.profissao_id);
                itensLidos++;
                if (itensLidos === _listaProfissoes.length) {
                    callback(null, { status_code: 200, profissoesIds: retorno });
                    return;
                }
            });
        }, this);
    } else {
        callback(null, { status_code: 200, categorias: retorno });
        return;
    }
};

exports.gravaProfissaoPorFotografo = function (_profissao, callback) {
    createProfissaoPorFotografo(_profissao, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
        return;
    });
};

exports.exlcuiProfissaoPorFotografo = function (_fotografoId, _profissaoId, callback) {
    deleteProfissaoPorFotografo(_fotografoId, _profissaoId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
        return;
    });
};

function devolveListaProfissoes(_listaIds, callback) {
    var retorno = [];
    var itensLidos = 0;
    if (_listaIds !== null) {
        _listaIds.forEach(function (item) {
            buscaProfissaoPoId(item.profissao_id, function (err, resp) {
                if (err) {
                    callback(err);
                    return;
                }

                retorno.push(resp.profissao);
                itensLidos++;
                if (itensLidos === _listaIds.length) {
                    callback(null, { status_code: 200, profissoes: retorno });
                    return;
                }
            });
        }, this);
    } else {
        callback(null, { status_code: 200, profissoes: retorno });
        return;
    }
}

function listaPorFotografo(_fotografoId, callback) {
    FotografoProfissao.findAll({
        where: {
            fotografo_id: _fotografoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, profissoes: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaProfissaoPoId(_categoriaId, callback) {
    Profissao.findOne({
        where: {
            id: _categoriaId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, profissao: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function listaTodas(callback) {
    Profissao.findAll()
        .then(function (resp) {
            callback(null, { status_code: 200, profissoes: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function createProfissaoPorFotografo(_profissao, callback) {
    FotografoProfissao.create(_profissao)
        .then(function (resp) {
            callback(null, { status_code: 200, fotografoProfissao: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function deleteProfissaoPorFotografo(_fotografoId, _profissaoId, callback) {
    FotografoProfissao.destroy({
        where: {
            fotografo_id: _fotografoId,
            profissao_id: _profissaoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200 });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}