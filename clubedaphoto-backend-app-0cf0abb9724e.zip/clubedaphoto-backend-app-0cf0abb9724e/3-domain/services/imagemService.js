var dropboxService = require('../services/dropboxService');
var im = require('imagemagick');

exports.gravaImagem = function (_file, path, callback) {
    dropboxService.buffer(_file.path, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        dropboxService.upload(path, resp.buff, function (err, res) {
            if (err) {
                callback(err);
                return;
            }

            dropboxService.getUrl(res.uploadDropBox.path, function (failed, suc) {
                if (failed) {
                    callback(failed);
                    return;
                }

                callback(null, { status_code: 200, path: path, url: suc.url });
                return;
            });
        });
    });
};

exports.excluiImagem = function (path, callback) {
    dropboxService.delete(path, function (erro, resposta) {
        if (erro) {
            console.error("Erro ao excluir do dropbox!", erro);
        }

        callback(null, { status_code: 200, msg: "Foto excluída com sucesso!" });
        return;
    });
};

exports.resizeImage = function (_filePath, _tamanho, callback) {
    im.convert([_filePath, '-resize', _tamanho, _filePath], function (err, stdout) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, _filePath);
        return;
    });
};