var FotografoFavorito = require('../models/_context').fotografoFavorito;

exports.adicionaFavorito = function (_fotografoId, _favoritoId, callback) {
    var favorito = {
        fotografo_id: _fotografoId,
        fotografo_favorito_id: _favoritoId
    };

    create(favorito, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
    });
};

exports.removeFavorito = function (_fotografoId, _favoritoId, callback) {
    exclui(_fotografoId, _favoritoId, function (err, resp) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, { status_code: 200 });
    });
};

exports.buscaFotografoFavorito = function (_fotografoId, _favoritoId, callback) {
    buscaFotografoFavorito(_fotografoId, _favoritoId, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        callback(null, resp);
    });
};

function create(_favorito, callback) {
    FotografoFavorito.create(_favorito)
        .then(function (resp) {
            callback(null, { status_code: 200, favorito: resp.dataValues });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function exclui(_fotografoId, _favoritoId, callback) {
    FotografoFavorito.destroy({
        where: {
            fotografo_id: _fotografoId,
            fotografo_favorito_id: _favoritoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200 });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}

function buscaFotografoFavorito(_fotografoId, _favoritoId, callback) {
    FotografoFavorito.findOne({
        where: {
            fotografo_id: _fotografoId,
            fotografo_favorito_id: _favoritoId
        }
    })
        .then(function (resp) {
            callback(null, { status_code: 200, fotografoFavorito: resp });
            return null;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return null;
        });
}