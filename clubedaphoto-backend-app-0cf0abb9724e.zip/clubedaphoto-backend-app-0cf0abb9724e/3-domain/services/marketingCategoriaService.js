var MarketingCategoria = require('../models/_context').marketingCategoria;

exports.listagemDeCategorias = function (callback) {
    listaTodas(function (err, lista) {
        if (err) {
            callback(err);
            return;
        }

        callback(null, lista);
        return;
    });
};

exports.adicionaCategoria = function (_categoria, callback) {
    create(_categoria, function (error, resp) {
        if (error) {
            callback(error);
            return;
        }

        callback(null, resp);
        return;
    });
};

function listaTodas(callback) {
    MarketingCategoria.findAll()
        .then(function (resp) {
            callback(null, { status_code: 200, categorias: resp });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}

function create(_categoria, callback) {
    MarketingCategoria.create(_categoria)
        .then(function (resp) {
            callback(null, { status_code: 200, categoria: resp.dataValues });
            return;
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
            return;
        });
}