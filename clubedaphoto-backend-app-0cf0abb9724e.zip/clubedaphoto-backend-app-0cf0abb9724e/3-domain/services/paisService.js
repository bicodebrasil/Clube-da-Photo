var Pais = require('../models/_context').pais;

exports.listagemDePaises = function (callback) {
    listaTodos(function (err, lista) {
        if (err) {
            callback(err);
        }

        callback(null, lista);
    });
};

function listaTodos(callback) {
    Pais.findAll()
        .then(function (resp) {
            callback(null, { status_code: 200, paises: resp });
        })
        .catch(function (err) {
            callback({ error_code: 500, error_msg: err });
        });
}