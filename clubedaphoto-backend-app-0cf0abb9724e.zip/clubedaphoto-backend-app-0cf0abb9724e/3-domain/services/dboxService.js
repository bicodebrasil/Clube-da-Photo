// var dbox = require("dbox");
// var env_ambiente = 'test';

// if (process.argv[2]) {
//     if (process.argv[2].indexOf('.js') == -1) {
//         env_ambiente = process.argv[2];
//     }
// }

// var config = require(__diInfra + 'config/config')[env_ambiente].dropbox;
// var app = dbox.app({ "app_key": config.app_key, "app_secret": config.app_secret });

// app.requesttoken(function (status, request_token) {
//     console.log(request_token);
//     //Autorizar URl que vai aparecer no console
//     app.accesstoken(request_token, function (status, access_token) {
//         console.log(access_token);
//         //Pegar os dados da console e gravar no config.js
//         var client = app.client(access_token);
//         exports.client = client;
//     });
// });