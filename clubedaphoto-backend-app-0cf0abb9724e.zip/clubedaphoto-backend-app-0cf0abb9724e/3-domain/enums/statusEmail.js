var Enum = require('enum');

var _statusEmail = new Enum({
    'Enviado': 1,
    'Não enviado': 2,
});
exports.statusEmail = _statusEmail;