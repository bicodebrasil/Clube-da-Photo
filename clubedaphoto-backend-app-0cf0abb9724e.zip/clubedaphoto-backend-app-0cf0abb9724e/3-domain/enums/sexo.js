var Enum = require('enum');

var _sexo = new Enum({
    'Masculino': 1,
    'Feminino': 2,
    'Outros': 3
});
exports.sexo = _sexo;