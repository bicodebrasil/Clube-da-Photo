var Enum = require('enum');

var _tipoMidia = new Enum({
    'Foto': 1,
    'Vídeo': 2,
});
exports.tipoMidia = _tipoMidia;