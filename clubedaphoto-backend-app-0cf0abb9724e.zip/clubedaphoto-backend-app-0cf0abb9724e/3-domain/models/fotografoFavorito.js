module.exports = function (sequelize, DataTypes) {
    var fotografoFavorito = sequelize.define('fotografoFavorito', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fotografo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        fotografo_favorito_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_fotografo_favorito'
        });
    return fotografoFavorito;
};      