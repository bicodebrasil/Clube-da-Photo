module.exports = function (sequelize, DataTypes) {
    var feedback = sequelize.define('feedback', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fotografo_id: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        texto: {
            type: DataTypes.STRING(500),
            allowNull: false
        },
        status_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        data_criacao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        },
        data_alteracao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        }
    },
        {
            createdAt: 'data_criacao',
            updatedAt: 'data_alteracao',
            timestamps: true,
            freezeTableName: true,
            tableName: 'tb_feedback'
        });
    return feedback;
};      