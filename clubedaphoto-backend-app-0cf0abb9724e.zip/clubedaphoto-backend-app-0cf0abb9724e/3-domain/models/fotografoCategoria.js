module.exports = function (sequelize, DataTypes) {
    var fotografoCategoria = sequelize.define('fotografoCategoria', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fotografo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        categoria_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_fotografo_categoria'
        });
    return fotografoCategoria;
};      