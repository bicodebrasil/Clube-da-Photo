var fs = require('fs');
var path = require('path');
var Sequelize = require('sequelize');
var env_ambiente = 'test';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}
var config = require(__dirname + '/../../4-infra/config/config.json')[env_ambiente];

// ==================================================================
// Configuracao do MySQL
// ==================================================================
var context = new Sequelize(config.master.database,
    config.master.username,
    config.master.password,
    config.master);

context.authenticate()
    .then(function (err) {
        console.log('Conexão estabelecida com sucesso!.');
    })
    .catch(function (err) {
        console.log('Não foi possível estabelecer conexão com o banco de dados:', err);
    });

// ==================================================================
// Models MySQL
// ==================================================================
exports.context = context;
exports.token = context.import('../models/token');
exports.pais = context.import('../models/pais');
exports.estado = context.import('../models/estado');
exports.cidade = context.import('../models/cidade');
exports.categoria = context.import('../models/categoria');
exports.profissao = context.import('../models/profissao');
exports.fotografo = context.import('../models/fotografo');
exports.fotografoCategoria = context.import('../models/fotografoCategoria');
exports.fotografoProfissao = context.import('../models/fotografoProfissao');
exports.fotografoMidia = context.import('../models/fotografoMidia');
exports.fotografoFavorito = context.import('../models/fotografoFavorito');
exports.anuncio = context.import('../models/anuncio');
exports.marketingCategoria = context.import('../models/marketingCategoria');
exports.feedback = context.import('../models/feedback');