module.exports = function (sequelize, DataTypes) {
    var token = sequelize.define('token', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false
        },
        token: {
            type: DataTypes.STRING(255),
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_token'
        });
    return token;
};