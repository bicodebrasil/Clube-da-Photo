module.exports = function (sequelize, DataTypes) {
    var categoria = sequelize.define('categoria', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        descricao: {
            type: DataTypes.STRING(50),
            allowNull: false
        },
        icone: {
            type: DataTypes.STRING(50),
            allowNull: true
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_categoria'
        });
    return categoria;
};      