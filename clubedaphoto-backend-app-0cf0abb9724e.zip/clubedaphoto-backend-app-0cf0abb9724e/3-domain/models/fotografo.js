module.exports = function (sequelize, DataTypes) {
    var fotografo = sequelize.define('fotografo', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nome: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        nome_exibicao: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        descricao: {
            type: DataTypes.STRING(2000),
            allowNull: false
        },
        is_empresa: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: false
        },
        site: DataTypes.STRING(500),
        foto_perfil_path: DataTypes.STRING(500),
        foto_perfil_url: DataTypes.STRING(500),
        facebook_id: DataTypes.STRING(500),
        facebook_access_token: DataTypes.STRING(500),
        facebook_expiration_date: DataTypes.STRING(500),
        sexo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        telefone: {
            type: DataTypes.STRING(50),
            allowNull: false
        },
        celular: DataTypes.STRING(50),
        is_whatsapp: DataTypes.BOOLEAN,
        ano_inico_trabalho: DataTypes.INTEGER,
        senha: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        pais_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        estado_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        cep: {
            type: DataTypes.STRING(15),
            allowNull: false
        },
        cidade_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        bairro: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        rua: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        numero: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        complemento: DataTypes.STRING(255),
        is_ativo: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        facebook_url: DataTypes.STRING(500),
        instagram_url: DataTypes.STRING(500),
        youtube_url: DataTypes.STRING(500),
        vimeo_url: DataTypes.STRING(500),
        twitter_url: DataTypes.STRING(500),
        linkedin_url: DataTypes.STRING(500),
        google_plus_url: DataTypes.STRING(500),
        token: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        data_criacao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        },
        data_alteracao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        },
        geo_latitude: {
            type: DataTypes.STRING(50),
            allowNull: false
        },
        geo_longitude: {
            type: DataTypes.STRING(50),
            allowNull: false
        }
    },
        {
            createdAt: 'data_criacao',
            updatedAt: 'data_alteracao',
            timestamps: true,
            freezeTableName: true,
            tableName: 'tb_fotografo'
        });
    return fotografo;
};      