module.exports = function (sequelize, DataTypes) {
    var estado = sequelize.define('estado', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nome: {
            type: DataTypes.STRING(100),
            allowNull: false
        },
        uf: {
            type: DataTypes.STRING(2),
            allowNull: false
        },
        pais_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_estado'
        });
    return estado;
};