module.exports = function (sequelize, DataTypes) {
    var pais = sequelize.define('pais', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        nome: {
            type: DataTypes.STRING(50),
            allowNull: false
        },
        sigla: {
            type: DataTypes.STRING(2),
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_pais'
        });
    return pais;
};