module.exports = function (sequelize, DataTypes) {
    var fotografoMidia = sequelize.define('fotografoMidia', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fotografo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        descricao: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        tipo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        foto_original_path: DataTypes.STRING(500),
        foto_original_url: DataTypes.STRING(500),
        foto_menor_path: DataTypes.STRING(500),
        foto_menor_url: DataTypes.STRING(500),
        video_url: DataTypes.STRING(500),
        data_criacao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        },
        data_alteracao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaultValue: new Date()
        }
    },
        {
            createdAt: 'data_criacao',
            updatedAt: 'data_alteracao',
            timestamps: true,
            freezeTableName: true,
            tableName: 'tb_fotografo_midia'
        });
    return fotografoMidia;
};      