module.exports = function (sequelize, DataTypes) {
    var profissao = sequelize.define('profissao', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        descricao: {
            type: DataTypes.STRING(50),
            allowNull: false
        },
        icone: {
            type: DataTypes.STRING(50),
            allowNull: true
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_profissao'
        });
    return profissao;
};      