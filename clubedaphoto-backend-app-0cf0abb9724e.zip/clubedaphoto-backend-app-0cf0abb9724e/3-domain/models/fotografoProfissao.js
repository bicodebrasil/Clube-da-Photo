module.exports = function (sequelize, DataTypes) {
    var fotografoProfissao = sequelize.define('fotografoProfissao', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        fotografo_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        profissao_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    },
        {
            timestamps: false,
            freezeTableName: true,
            tableName: 'tb_fotografo_profissao'
        });
    return fotografoProfissao;
};      