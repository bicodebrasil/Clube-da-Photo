module.exports = function (sequelize, DataTypes) {
    var anuncio = sequelize.define('anuncio', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        categoria_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        url: {
            type: DataTypes.STRING(500),
            allowNull: true
        },
        foto_anuncio_path: DataTypes.STRING(500),
        foto_anuncio_url: DataTypes.STRING(500),
        data_criacao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaulValue: new Date()
        },
        data_alteracao: {
            type: DataTypes.DATE,
            allowNull: false,
            defaulValue: new Date()
        }
    },
        {
            createdAt: 'data_criacao',
            updatedAt: 'data_alteracao',
            timestamps: true,
            freezeTableName: true,
            tableName: 'tb_anuncio'
        });
    return anuncio;
};      