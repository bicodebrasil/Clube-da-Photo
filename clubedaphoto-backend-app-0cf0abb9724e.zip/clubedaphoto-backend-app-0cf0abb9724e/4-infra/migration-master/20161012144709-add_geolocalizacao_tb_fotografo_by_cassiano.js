module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.addColumn(
			'tb_fotografo',
			'geo_latitude', {
				type: Sequelize.STRING(50),
				allowNull: false
			});

		queryInterface.addColumn(
			'tb_fotografo',
			'geo_longitude', {
				type: Sequelize.STRING(50),
				allowNull: false
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.removeColumn('geo_latitude', 'tb_fotografo');
		queryInterface.removeColumn('geo_longitude', 'tb_fotografo');
	}
};