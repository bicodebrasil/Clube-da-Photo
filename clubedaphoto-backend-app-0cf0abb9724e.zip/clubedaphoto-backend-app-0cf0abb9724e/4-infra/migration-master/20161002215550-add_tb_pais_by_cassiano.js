module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_pais', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			nome: {
				type: Sequelize.STRING(50),
				allowNull: false
			},
			sigla: {
				type: Sequelize.STRING(2),
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_pais');
	}
};