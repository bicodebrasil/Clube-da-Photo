module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_fotografo_profissao', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			fotografo_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			profissao_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_fotografo_profissao');
	}
};