module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_marketing_categoria', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			descricao: {
				type: Sequelize.STRING(50),
				allowNull: false
			},
			icone: {
				type: Sequelize.STRING(50),
				allowNull: true
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});

		queryInterface.createTable('tb_anuncio', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			categoria_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			url: {
				type: Sequelize.STRING(500),
				allowNull: true
			},
			foto_anuncio_path: Sequelize.STRING(500),
			foto_anuncio_url: Sequelize.STRING(500),
			data_criacao: {
				type: Sequelize.DATE,
				allowNull: false
			},
			data_alteracao: {
				type: Sequelize.DATE,
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_marketing_categoria');
		queryInterface.dropTable('tb_anuncio');
	}
};