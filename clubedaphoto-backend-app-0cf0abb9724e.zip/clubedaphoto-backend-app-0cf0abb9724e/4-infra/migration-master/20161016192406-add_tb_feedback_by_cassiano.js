module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_feedback', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			fotografo_id: {
				type: Sequelize.INTEGER,
				allowNull: true
			},
			texto: {
				type: Sequelize.STRING(500),
				allowNull: false
			},
			status_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			data_criacao: {
				type: Sequelize.DATE,
				allowNull: false
			},
			data_alteracao: {
				type: Sequelize.DATE,
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_feedback');
	}
};