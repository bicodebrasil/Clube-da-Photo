module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.addColumn(
			'tb_fotografo',
			'cep', {
				type: Sequelize.STRING(15),
				allowNull: false
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.removeColumn('cep', 'tb_fotografo');
	}
};