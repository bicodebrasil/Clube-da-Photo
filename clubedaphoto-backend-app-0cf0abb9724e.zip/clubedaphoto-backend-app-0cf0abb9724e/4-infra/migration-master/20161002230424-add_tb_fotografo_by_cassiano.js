module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_fotografo', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			nome: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			nome_exibicao: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			descricao: {
				type: Sequelize.STRING(2000),
				allowNull: false
			},
			is_empresa: {
				type: Sequelize.BOOLEAN,
				allowNull: false,
				defaultValue: false
			},
			site: Sequelize.STRING(500),
			foto_perfil_path: Sequelize.STRING(500),
			foto_perfil_url: Sequelize.STRING(500),
			facebook_id: Sequelize.STRING(500),
			facebook_access_token: Sequelize.STRING(500),
			facebook_expiration_date: Sequelize.STRING(500),
			sexo_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			email: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			telefone: {
				type: Sequelize.STRING(50),
				allowNull: false
			},
			celular: Sequelize.STRING(50),
			is_whatsapp: Sequelize.BOOLEAN,
			ano_inico_trabalho: Sequelize.INTEGER,
			senha: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			pais_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			estado_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			cidade_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			cep: {
				type: Sequelize.STRING(15),
				allowNull: false
			},
			bairro: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			rua: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			numero: {
				type: Sequelize.INTEGER,
				allowNull: false
			},
			complemento: Sequelize.STRING(255),
			is_ativo: {
				type: Sequelize.BOOLEAN,
				allowNull: false,
				defaultValue: true
			},
			facebook_url: Sequelize.STRING(500),
			instagram_url: Sequelize.STRING(500),
			youtube_url: Sequelize.STRING(500),
			vimeo_url: Sequelize.STRING(500),
			twitter_url: Sequelize.STRING(500),
			linkedin_url: Sequelize.STRING(500),
			google_plus_url: Sequelize.STRING(500),
			token: {
				type: Sequelize.STRING(255),
				allowNull: false
			},
			data_criacao: {
				type: Sequelize.DATE,
				allowNull: false
			},
			data_alteracao: {
				type: Sequelize.DATE,
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_fotografo');
	}
};