module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("INSERT INTO `tb_marketing_categoria`(`id`,`descricao`,`icone`)VALUES (1,'Seguradora','icon-seguradora'),(2,'Equipamentos','icon-equipamento'),(3,'Aluguel de Estúdio','icon-aluguel-studio'),(4,'Revistas','icon-revistas'),(5,'Encadernadoras','icon-encadernadoras') ,(6,'Cursos','icon-cursos'),(7,'WorkShops','icon-workshops'),(8,'Softwares','icon-softwares'),(9,'Empresas','icon-empresas'),(10,'Locações','icon-locacoes') ,(11,'Sites | Blogs','icon-sites-blogs'),(12,'Youtube','icon-youtube'),(13,'Congressos','icon-congressos'),(14,'Artes e Gráficas','icon-artes-graficas');");
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("DELETE FROM `tb_marketing_categoria` WHERE `id` > 0");
	}
};