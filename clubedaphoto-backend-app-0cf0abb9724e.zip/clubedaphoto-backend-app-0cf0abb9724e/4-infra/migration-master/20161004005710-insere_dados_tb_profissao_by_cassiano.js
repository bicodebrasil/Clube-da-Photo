module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("INSERT INTO `tb_profissao`(`id`,`descricao`,`icone`)VALUES (1,'Fotografo','ion-camera')," +
			"(2,'Cinegrafista','ion-videocamera'),(3,'Diagramador','ion-ios-book-outline'),(4,'Editor','ion-android-arrow-dropright-circle');");
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("DELETE FROM `tb_profissao` WHERE `id` > 0");
	}
};