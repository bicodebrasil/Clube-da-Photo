module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_token', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			token: {
				type: Sequelize.STRING(255),
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_token');
	}
};