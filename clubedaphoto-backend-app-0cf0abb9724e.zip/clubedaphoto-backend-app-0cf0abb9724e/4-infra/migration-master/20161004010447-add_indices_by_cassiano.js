module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("CREATE INDEX idx_estado_pais ON tb_estado (pais_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_cidade_estado ON tb_cidade (estado_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_midia_fotografo ON tb_fotografo_midia (fotografo_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_token_fotografo ON tb_fotografo (token);");
		queryInterface.sequelize.query("CREATE INDEX idx_pais_fotografo ON tb_fotografo (pais_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_estado_fotografo ON tb_fotografo (estado_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_cidade_fotografo ON tb_fotografo (cidade_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_fotografo_categoria ON tb_fotografo_categoria (fotografo_id, categoria_id);");
		queryInterface.sequelize.query("CREATE INDEX idx_fotografo_profissao ON tb_fotografo_profissao (fotografo_id, profissao_id);");
	},

	down: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("DROP INDEX idx_estado_pais ON tb_estado;");
		queryInterface.sequelize.query("DROP INDEX idx_cidade_estado ON tb_cidade;");
		queryInterface.sequelize.query("DROP INDEX idx_midia_fotografo ON tb_fotografo_midia;");
		queryInterface.sequelize.query("DROP INDEX idx_token_fotografo ON tb_fotografo;");
		queryInterface.sequelize.query("DROP INDEX idx_pais_fotografo ON tb_fotografo;");
		queryInterface.sequelize.query("DROP INDEX idx_estado_fotografo ON tb_fotografo;");
		queryInterface.sequelize.query("DROP INDEX idx_cidade_fotografo ON tb_fotografo;");
		queryInterface.sequelize.query("DROP INDEX idx_fotografo_categoria ON tb_fotografo_categoria;");
		queryInterface.sequelize.query("DROP INDEX idx_fotografo_profissao ON tb_fotografo_profissao;");
	}
};