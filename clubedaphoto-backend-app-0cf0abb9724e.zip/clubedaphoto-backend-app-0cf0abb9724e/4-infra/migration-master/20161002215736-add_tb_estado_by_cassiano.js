module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_estado', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			nome: {
				type: Sequelize.STRING(100),
				allowNull: false
			},
			uf: {
				type: Sequelize.STRING(2),
				allowNull: false
			},
			pais_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_estado');
	}
};