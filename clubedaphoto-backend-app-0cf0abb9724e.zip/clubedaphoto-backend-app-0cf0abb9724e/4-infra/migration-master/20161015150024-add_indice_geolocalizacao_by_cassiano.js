module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("CREATE INDEX idx_geolocalizacao ON tb_fotografo (geo_latitude, geo_longitude);");
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.sequelize.query("DROP INDEX idx_geolocalizacao ON tb_fotografo;");
	}
};