module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_cidade', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			nome: {
				type: Sequelize.STRING(100),
				allowNull: false
			},
			estado_id: {
				type: Sequelize.INTEGER,
				allowNull: false
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_cidade');
	}
};