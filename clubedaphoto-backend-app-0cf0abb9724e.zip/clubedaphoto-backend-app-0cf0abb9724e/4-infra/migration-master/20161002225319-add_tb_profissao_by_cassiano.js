module.exports = {
	up: function (queryInterface, Sequelize) {
		queryInterface.createTable('tb_profissao', {
			id: {
				type: Sequelize.INTEGER,
				primaryKey: true,
				autoIncrement: true
			},
			descricao: {
				type: Sequelize.STRING(50),
				allowNull: false
			},
			icone: {
				type: Sequelize.STRING(50),
				allowNull: true
			}
		},
			{
				engine: 'InnoDB',                     // default: 'InnoDB'
				charset: 'utf8',                    // default: null
			});
	},
	down: function (queryInterface, Sequelize) {
		queryInterface.dropTable('tb_profissao');
	}
};