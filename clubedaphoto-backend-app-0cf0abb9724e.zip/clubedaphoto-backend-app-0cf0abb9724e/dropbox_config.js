var dbox = require("dbox");

var env_ambiente = 'test';
if (process.argv[2]) {
    if (process.argv[2].indexOf('.js') == -1) {
        env_ambiente = process.argv[2];
    }
}

var config = require(__dirname + '/4-infra/config/config.json')[env_ambiente];

var funcao = function () {
    var client = module.exports;
    var appToken = config.dropbox;
    var access_token = config.access_token_dropbox;
    var app = dbox.app(appToken);

    return client = module.exports = app.client(access_token);
} ();
exports.client = funcao;